var x = 100;
var y = 100;

function setup() {
  createCanvas(800,500);
  stroke("#666666"); 
  fill("#4FBDF2");
}

function draw() {
  
}