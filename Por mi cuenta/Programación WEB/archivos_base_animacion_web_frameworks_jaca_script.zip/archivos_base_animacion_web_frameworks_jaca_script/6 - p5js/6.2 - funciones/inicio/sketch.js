var x = 200;
var y = 200;


function setup() {
  createCanvas(800,500);
}

function draw() {
  background("#4AF2A1");
  ellipse(250, 150, 80, 80);
}