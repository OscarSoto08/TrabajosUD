package proycombobox;

import control.Controlador;

public class ProyComboBox {
    public static void main(String[] args) 
    {
        Controlador control = new Controlador();
        
        control.iniciar();
    }
}
