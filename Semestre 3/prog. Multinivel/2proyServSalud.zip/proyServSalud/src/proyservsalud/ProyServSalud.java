/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyservsalud;

import controlador.*;

/**
 *
 * @author Estudiante
 */
public class ProyServSalud {

    public static void main(String[] args) {
        
        ControlMDI objC = new ControlMDI();
        objC.iniciar();
    }
    
}
