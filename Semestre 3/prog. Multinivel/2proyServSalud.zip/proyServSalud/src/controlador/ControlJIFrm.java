/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import modelo.Consulta;
import modelo.Examen;
import modelo.Factura;
import modelo.Fecha;
import vista.*;

public class ControlJIFrm implements ActionListener{
    Factura objF;
    frmJIVentanaCB frmV;

    public ControlJIFrm() {
        this.objF = new Factura();
        this.frmV = new frmJIVentanaCB();
    } 
    
    public ControlJIFrm(frmJIVentanaCB frmV) {
        this.objF = new Factura();
        this.frmV = frmV;
    } 
    
    public void iniciar()
    {
        this.frmV.getCmbServicio().addActionListener(this);
        this.frmV.getBtnAgregar().addActionListener(this);
        this.frmV.getBtnRegistrar().addActionListener(this);
        
        this.frmV.getBtnRegistrar().setEnabled(false);
        this.frmV.getBtnAgregar().setEnabled(false);
        this.frmV.getPnlConsulta().setVisible(false);
        
        frmV.setTitle("Servicios de salud");
        frmV.setVisible(true);
        frmV.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmV.setLocation(200,200);
    }
    
    public void RegistrarTbl()
    {
        DefaultTableModel tabla = (DefaultTableModel) frmV.getTblRegistro().getModel();
        Object[] datos = {
            objF.getFechaFactura(),
            objF.getObjP().getIdPaciente(),
            objF.getObjP().getNombre(),
            objF.getObjP().getCategoria(),
            objF.getObjS().getCodigo(),
            objF.getObjS().valorPago(objF.getObjP())
        };
        tabla.addRow(datos);
    }
    public void limpiarTxt()
    {
        JTextField[] objsTxt = 
        {
            frmV.getTxtCategoria(),
            frmV.getTxtDescripcion(),
            frmV.getTxtFechaConsulta(),
            frmV.getTxtFechaNacimiento(),
            frmV.getTxtNombre(),
            frmV.getTxtTelefono()
        };
        
        for(JTextField elemento: objsTxt)
        {
            elemento.setText("");
        }
    }
    
    public void leerPaciente()
    {
        objF.getObjP().setCategoria(frmV.getTxtCategoria().getText().charAt(0));
        String[] fechaNac = frmV.getTxtFechaNacimiento().getText().split("/");
        objF.getObjP().setFechaNac(new Fecha(Integer.parseInt(fechaNac[0]),
                                                       Integer.parseInt(fechaNac[1]),
                                                       Integer.parseInt(fechaNac[2])));
        objF.getObjP().setNombre(frmV.getTxtNombre().getText());
        objF.getObjP().setTelefono(frmV.getTxtTelefono().getText());
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource().equals(frmV.getCmbServicio()))
        {
            frmV.getBtnAgregar().setEnabled(true);
            switch(frmV.getCmbServicio().getSelectedIndex())
            {
                case 0 -> this.frmV.getPnlConsulta().setVisible(false);
                case 1 -> this.frmV.getPnlConsulta().setVisible(true);
            }
        }
        
        if(e.getSource().equals(frmV.getBtnAgregar()))
        {
            leerPaciente();
            switch(frmV.getCmbServicio().getSelectedIndex())
            {
                case 0 -> {
                    Examen exa = new Examen();
                    exa.setDescripcion(frmV.getTxtDescripcion().getText());
                    objF.setObjS(exa);
                }
                case 1 -> {
                    Consulta con = new Consulta();
                    con.setDescripcion(frmV.getTxtDescripcion().getText());
                    String[] fechaCon = frmV.getTxtFechaNacimiento().getText().split("/");
                    con.setFechaConsulta(new Fecha(Integer.parseInt(fechaCon[0]),
                                                                                    Integer.parseInt(fechaCon[1]),
                                                                                    Integer.parseInt(fechaCon[2])));
                    objF.setObjS(con);
                }
            }
            RegistrarTbl();
            limpiarTxt();
        }
    }
}
