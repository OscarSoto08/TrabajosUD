package modelo;

public class Consulta extends Servicio{

    Fecha fechaConsulta;

    public Consulta(Fecha fechaConsulta, String codigo, String descripcion) {
        super(codigo, descripcion);
        this.fechaConsulta = fechaConsulta;
    }

    public Consulta() {
        super();
        this.fechaConsulta = new Fecha();
    }

    public Fecha getFechaConsulta() {
        return fechaConsulta;
    }

    public void setFechaConsulta(Fecha fechaConsulta) {
        this.fechaConsulta = fechaConsulta;
    }
    
    @Override
    public double valorPago(Paciente objP) {
        return switch(objP.getCategoria()){
            case 'a','A' -> 5000;
            case 'b','B' -> 8000;
            case 'c','C' -> 15000;
            default -> 20000;
        };
    }

    @Override
    public String toString() {
        return super.toString() 
                + "\nFecha de Consulta:" + fechaConsulta;
    }
}
