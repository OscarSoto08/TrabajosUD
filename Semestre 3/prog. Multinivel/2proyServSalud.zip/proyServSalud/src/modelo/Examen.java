/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
/**
 *
 * @author Estudiante
 */

public class Examen extends Servicio{

    public Examen(String codigo, String descripcion) {
        super(codigo, descripcion);
    }

    public Examen() {
        super();
    }
    
    @Override
    public double valorPago(Paciente objP) { 
        return switch (objP.getCategoria()) {
            case 'a', 'A' -> 5000;
            case 'b', 'B' -> 8000;
            case 'c', 'C' -> 15000;
            default -> 20000;
        };
    }
    
    @Override
    public String toString()
    {
        return super.toString();
    }
}
