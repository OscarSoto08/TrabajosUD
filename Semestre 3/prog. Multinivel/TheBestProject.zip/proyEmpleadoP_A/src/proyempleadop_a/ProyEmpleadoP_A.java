package proyempleadop_a;

import controlador.ControlRec;

public class ProyEmpleadoP_A {

    public static void main(String[] args) {
        controlador.ControlRec obj = new ControlRec();
        obj.iniciar();
    }
    
}
