/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import modelo.Formulario;
import vista.*;
/**
 *
 * @author nailu
 */
public class ControladorMDI implements ActionListener{
    MDIinicio frmI;
    Formulario objF;

    public ControladorMDI() {
        this.frmI = new MDIinicio();
        this.objF = new Formulario();
    }
    
    public void iniciar(){
        this.frmI.getMnuNuevoF().addActionListener(this);
        this.frmI.getMnuSalir().addActionListener(this);
        this.frmI.getBtnNuevoF().addActionListener(this);
        this.frmI.getBtnRecaudo().addActionListener(this);
        this.frmI.getBtnSalir().addActionListener(this);
        
        frmI.setTitle("Registro de Vehiculos: ");
        frmI.setLocationRelativeTo(null);
        frmI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmI.setVisible(true);
    }
    
    public void agregarVehiculo(JTable tabla, Formulario formV){
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        plantilla.addRow(formV.Registro());
    }
    
    private void iniciarControles(Component [] controles) {
        int cantTab = 0;
        for (Component control : controles) {
            if (control instanceof JTabbedPane) {
                cantTab = ((JTabbedPane) control).getTabCount();
                for (int i = 0; i < cantTab; i++) {
                    Component panel = ((JTabbedPane) control).getComponent(i);
                    iniciarControles( ((JPanel)panel).getComponents());
                }
            }else if (control instanceof JPanel) {
                //Recursividad
                iniciarControles(((JPanel) control).getComponents());
            }else if (control instanceof JTextField){
                ((JTextField) control).setText("");
            }
        }
    }
    
//    private void iniciarTable()
//    {
//        
//    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==frmI.getMnuSalir()||e.getSource()==frmI.getBtnSalir()){
            int resp = JOptionPane.showConfirmDialog(frmI, "Desea terminar la ejecucion?..");
            if(resp==JOptionPane.YES_OPTION){
                frmI.dispose();
                //Como formatear el No y el Cancel?
                //al ejercico del extracto hacerle la interface solamente en jframe
                //Solo un extracto por empleado, nada mas
                
            }
        }
        if(e.getSource()==frmI.getMnuNuevoF()||e.getSource()==frmI.getBtnNuevoF()){
            JIFrmVehiculo frmV = new JIFrmVehiculo();//1. Crear jInternal
            frmI.getEscritorio().add(frmV); //2. Agregar el escritoiro
            //frmV.setVisible(true); //3. Mostrar
            
        }
    }
}
