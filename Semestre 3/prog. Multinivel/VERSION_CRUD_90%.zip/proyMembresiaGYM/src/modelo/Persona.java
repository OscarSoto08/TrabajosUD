/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Calendar;

public class Persona {
    private String nombre;
    private Fecha fechaNac;
    private String telefono;
    private String correo;
    private String ciudad;
    private String ID;

    public Persona(String nombre, String telefono, String correo, String ciudad, String ID) {
        this.nombre = nombre;
        this.fechaNac = fechaNac;
        this.telefono = telefono;
        this.correo = correo;
        this.ciudad = ciudad;
        this.ID = ID;
    }

    
    public Persona() {
        this.nombre = "";
        this.fechaNac = new Fecha();
        this.telefono = "";
        this.correo = "";
        this.ciudad = "";
        this.ID = "";
    }
    
    public String calcularEdad() {
        try {
            Calendar fechaSis = Calendar.getInstance(); // Obtener fecha y año actual
            int añoActual = fechaSis.get(Calendar.YEAR);
            int añoNacimiento = fechaNac.getAño();

            int edad = añoActual - añoNacimiento;

            // Verificar si la persona tiene menos de 1 año
            if (edad <= 0) {
                return "La persona tiene menos de 1 año.";
            } else {
                return "Años: " + edad;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "Error al calcular la edad.";
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Fecha getFechaNac() {
        return fechaNac;
    }

    public void setFechaNac(Fecha fechaNac) {
        this.fechaNac = fechaNac;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }
    
    @Override
    public String toString() {
        return "Nombre: " + nombre + 
                "\nEdad: " + calcularEdad() + " años" + 
                "\nTelefono: " + telefono + 
                "\nCorreo: " + correo + 
                "\nCiudad: " + ciudad + 
                "\nID: " + ID;
    }
}
