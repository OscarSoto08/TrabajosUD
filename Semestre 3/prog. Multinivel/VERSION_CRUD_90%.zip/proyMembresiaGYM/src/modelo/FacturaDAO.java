package modelo;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FacturaDAO {
    private Factura_Gym objF;

    public FacturaDAO(Factura_Gym objP) {
        this.objF = objP;
    }

    public FacturaDAO() {
        this.objF = new Factura_Gym();
    }

    public DefaultTableModel consultar() {
        DefaultTableModel plantilla = new DefaultTableModel();
        ConexionBD con = new ConexionBD();
        try {
            con.conectar();
            JOptionPane.showMessageDialog(null, con.getMensaje());
            Statement consulta = con.getConexion().createStatement();
            ResultSet datos = consulta.executeQuery("SELECT * FROM factura_gym");
            ResultSetMetaData campos = datos.getMetaData();
            for (int i = 1; i <= campos.getColumnCount(); i++) {
                plantilla.addColumn(campos.getColumnName(i));
            }
            while (datos.next()) {
                Object fila[] = new Object[campos.getColumnCount()];
                for (int i = 0; i < campos.getColumnCount(); i++) {
                    fila[i] = datos.getObject(i + 1);
                }
                plantilla.addRow(fila);
            }
            datos.close();
            con.getConexion().close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString());
        }
        return plantilla;
    }

    public String insertar() {
        String mensaje = "";
        try {
            ConexionBD conexion = new ConexionBD();
            Statement consulta = null;
            conexion.conectar();
            String categoria = "";
            if (objF.getMemb() instanceof TipoA) {
                categoria = "A";
            } else if (objF.getMemb() instanceof TipoB) {
                categoria = "B";
            } else {
                categoria = "C";
            }

            String comando = "INSERT INTO factura_gym (idFact, fechaF, Id_Cliente, Id_Membresia) VALUES ("
                    + "'" + objF.getIdFact() + "', "
                    + "'" + objF.getFechaF().toString() + "', "
                    + "'" + objF.getPropietario().getID() + "', "
                    + "'" + categoria + "')";
            consulta = conexion.getConexion().createStatement();
            consulta.execute(comando);
            mensaje = "Registro exitoso...";
            consulta.close();
            conexion.getConexion().close();
        } catch (SQLException ex) {
            mensaje = "Error al intentar insertar...\n" + ex;
        }
        return mensaje;
    }

    public String actualizarFactura(Factura_Gym factura) {
        String mensaje = "";
        try {
            ConexionBD conexion = new ConexionBD();
            Statement consulta = null;
            conexion.conectar();
            String categoria = "";
            if (factura.getMemb() instanceof TipoA) {
                categoria = "A";
            } else if (factura.getMemb() instanceof TipoB) {
                categoria = "B";
            } else {
                categoria = "C";
            }

            String instruccion = "UPDATE factura_gym SET "
                    + "fechaF='" + factura.getFechaF().toString() + "', "
                    + "Id_Cliente='" + factura.getPropietario().getID() + "', "
                    + "Id_Membresia='" + categoria + "' "
                    + "WHERE idFact='" + factura.getIdFact() + "'";

            consulta = conexion.getConexion().createStatement();
            consulta.executeUpdate(instruccion);
            mensaje = "Actualización exitosa...";
            consulta.close();
            conexion.getConexion().close();
        } catch (SQLException ex) {
            mensaje = "Error al intentar actualizar...\n" + ex;
        }
        return mensaje;
    }

    public String eliminarFactura(String idFact) {
        String mensaje = "";
        try {
            ConexionBD conexion = new ConexionBD();
            Statement consulta = null;
            conexion.conectar();

            String comando = "DELETE FROM factura_gym WHERE idFact='" + idFact + "'";
            consulta = conexion.getConexion().createStatement();
            consulta.executeUpdate(comando);
            mensaje = "Factura eliminada correctamente...";
            consulta.close();
            conexion.getConexion().close();
        } catch (SQLException ex) {
            mensaje = "Error al intentar eliminar la factura...\n" + ex;
        }
        return mensaje;
    }

    public Factura_Gym getObjF() {
        return objF;
    }

    public void setObjF(Factura_Gym objF) {
        this.objF = objF;
    }

    @Override
    public String toString() {
        return objF.toString();
    }
}
