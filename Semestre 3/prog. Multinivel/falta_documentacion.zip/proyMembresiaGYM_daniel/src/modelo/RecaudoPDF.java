package modelo;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;

import javax.swing.JOptionPane;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class RecaudoPDF {

    private File ruta_destino;

    public RecaudoPDF() {
        // Define la ruta del archivo PDF en la raíz del proyecto
        this.ruta_destino = new File(System.getProperty("user.dir") + File.separator + "Recaudo_GYM.pdf");
    }

    /* Método que hace uso de la clase iText para manipular archivos PDF */
    public void generarRecaudo(Recaudo recaudo) {
        if (this.ruta_destino != null) {
            try {
                // Se crea una instancia del documento
                Document mipdf = new Document();
                // Se establece una instancia a un documento PDF
                PdfWriter.getInstance(mipdf, new FileOutputStream(this.ruta_destino));
                mipdf.open(); // Se abre el documento
                mipdf.addTitle("Recaudo Gimnasio");

                mipdf.add(new Paragraph("\tRecaudo de Gimnasio\n\n"));

                // Agregar los totales de membresía A, B y C al documento
                mipdf.add(new Paragraph("Total Membresía A: " + recaudo.getTotalMembresiaA()));
                mipdf.add(new Paragraph("Total Membresía B: " + recaudo.getTotalMembresiaB()));
                mipdf.add(new Paragraph("Total Membresía C: " + recaudo.getTotalMembresiaC()));

                // Agregar el total recaudado al documento
                mipdf.add(new Paragraph("\nTotal Recaudado: " + recaudo.getTotalRecaudado()));

                mipdf.close(); // Se cierra el PDF

                JOptionPane.showMessageDialog(null, "Documento PDF creado");

                // Abre el PDF automáticamente
                abrirPDF();

            } catch (DocumentException | FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, ex.toString());
            }
        }
    }

    /* Método para abrir el PDF */
    public void abrirPDF() {
        try {
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(this.ruta_destino);
            } else {
                JOptionPane.showMessageDialog(null, "No se puede abrir el PDF automáticamente.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error al abrir el PDF: " + ex.getMessage());
        }
    }

    public File getRuta_destino() {
        return ruta_destino;
    }

    public void setRuta_destino(File ruta_destino) {
        this.ruta_destino = ruta_destino;
    }
}
