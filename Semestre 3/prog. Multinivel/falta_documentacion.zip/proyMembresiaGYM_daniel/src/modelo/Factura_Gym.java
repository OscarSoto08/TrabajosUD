package modelo;

public class Factura_Gym {
    private String idFact;
    private Membresia memb;
    private Fecha fechaF;
    private Persona cliente;

    public Factura_Gym(String idFact, Membresia memb, Fecha fechaF, Persona cliente) {
        this.idFact = idFact;
        this.memb = memb;
        this.fechaF = fechaF;
        this.cliente = cliente;
    }
    
    public Factura_Gym() {
    this.idFact = "F-" + Math.round(100 + Math.random() * 999);
    this.fechaF = new Fecha();
    this.cliente = new Persona();
    this.memb = null; 
    }



    public Persona getPropietario() {
        return cliente;
    }
    public void setPropietario(Persona propietario) {
        this.cliente = propietario;
    }
    public String getIdFact() {
        return idFact;
    }
    public void setIdFact(String idFact) {
        this.idFact = idFact;
    }
    public Membresia getMemb() {
        return memb;
    }
    public void setMemb(Membresia memb) {
        this.memb = memb;
    }
    public Fecha getFechaF() {
        return fechaF;
    }
    public void setFechaF(Fecha fechaF) {
        this.fechaF = fechaF;
    }  
    public Object[] Registro(){
        String tipo = "";
        if (memb instanceof TipoA)
            tipo = "A";
        else if(memb instanceof TipoB)
            tipo = "B";
        else
            tipo = "C";
        Object[] reg = {
            cliente.getID(),
            cliente.getNombre(),
            tipo,
            memb.valorPago()
        };
        return reg;
    }
    
    public static Membresia convertirStringAMembresia(String tipo) {
        switch(tipo) {
            case "A":
                return new TipoA();
            case "B":
                return new TipoB();
            case "C":
                return new TipoC();
            default:
            // Lanza una excepción o retorna un valor por defecto
            throw new IllegalArgumentException("Tipo de membresía no válido: " + tipo);
        }
    }

    public static Fecha convertirStringAFecha(String fechaStr) {
    // Suponiendo el formato de fecha "dd/MM/yyyy"
    String[] partes = fechaStr.split("/");
    
    if (partes.length != 3) {
        // Manejo de error si la fecha no está en el formato esperado
        throw new IllegalArgumentException("Formato de fecha no válido. Debe ser dd/MM/yyyy.");
    }
    
    try {
        int dia = Integer.parseInt(partes[0]);
        int mes = Integer.parseInt(partes[1]);
        int año = Integer.parseInt(partes[2]);
        
        return new Fecha(dia, mes, año);
    } catch (NumberFormatException e) {
        // Manejo de error si las partes no son enteros válidos
        throw new IllegalArgumentException("Fecha contiene valores no numéricos.");
    }
}


    public static Persona convertirStringAPersona(String personaStr) {
        // Suponiendo que los datos de la persona están separados por comas en la cadena
        // Formato esperado: "nombre,telefono,correo,ciudad,ID"
        String[] partes = personaStr.split(",");

        if (partes.length != 6) {
            // Manejo de error si la cadena no contiene los 5 campos esperados
            throw new IllegalArgumentException("Formato de datos de persona no válido. Debe ser nombre,telefono,correo,ciudad,ID.");
        }

        // Asignar cada parte a la variable correspondiente
        String ID = partes[0].trim();
        String nombre = partes[1].trim();
        String telefono = partes[2].trim();
        String correo = partes[3].trim();
        String ciudad = partes[4].trim();
        String fecha = partes[5].trim();
        

        // Crear y retornar un objeto Persona
        return new Persona(nombre, telefono, correo, ciudad, ID, fecha);
    }

    @Override
    public String toString() {
        return """
               |------------------------------------------------------|\nFactura:
               id_Factura:""" + idFact + 
                "\nFecha_Factura: " + fechaF + 
                "\nCliente: \n" + cliente.toString() +
                "\nValor Pago: " + memb.valorPago() +
                "\n|------------------------------------------------------|";
    }
    
    
}
