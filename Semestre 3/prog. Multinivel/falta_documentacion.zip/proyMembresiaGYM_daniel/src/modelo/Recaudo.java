package modelo;

import java.util.ArrayList;

public class Recaudo {
    private ArrayList<Factura_Gym> listaF;

    public Recaudo(ArrayList<Factura_Gym> listaF) {
        this.listaF = listaF;
    }
    
    public Recaudo() {
        this.listaF = new ArrayList<>();
    }

    public ArrayList<Factura_Gym> getListaF() {
        return listaF;
    }

    public void setListaF(ArrayList<Factura_Gym> listaF) {
        this.listaF = listaF;
    }
    
    public String datos() {
        String datos = "";
        for (Factura_Gym factura : listaF) {
            datos += factura.toString();
        }
        return datos;
    }
    
    public double valorPago() {
        double datos = 0;
        for (Factura_Gym factura : listaF) {
            datos += factura.getMemb().valorPago();
        }
        return datos;
    }

    // Método para obtener el total de membresía A
    public double getTotalMembresiaA() {
        double totalMembresiaA = 0;
        for (Factura_Gym factura : listaF) {
            if (factura.getMemb() instanceof TipoA) {
                totalMembresiaA += factura.getMemb().valorPago();
            }
        }
        return totalMembresiaA;
    }

    // Método para obtener el total de membresía B
    public double getTotalMembresiaB() {
        double totalMembresiaB = 0;
        for (Factura_Gym factura : listaF) {
            if (factura.getMemb() instanceof TipoB) {
                totalMembresiaB += factura.getMemb().valorPago();
            }
        }
        return totalMembresiaB;
    }

    // Método para obtener el total de membresía C
    public double getTotalMembresiaC() {
        double totalMembresiaC = 0;
        for (Factura_Gym factura : listaF) {
            if (factura.getMemb() instanceof TipoC) {
                totalMembresiaC += factura.getMemb().valorPago();
            }
        }
        return totalMembresiaC;
    }

    // Método para calcular el total recaudado
    public double getTotalRecaudado() {
        return getTotalMembresiaA() + getTotalMembresiaB() + getTotalMembresiaC();
    }

    @Override
    public String toString() {
        return datos();
    }
}
