package main;
import control.*;

public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Controlador_MDI controlador = new Controlador_MDI();
        controlador.iniciar();
    }
}
    

