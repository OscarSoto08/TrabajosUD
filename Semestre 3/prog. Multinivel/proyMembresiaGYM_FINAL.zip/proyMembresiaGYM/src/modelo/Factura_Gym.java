package modelo;

/**
 * Clase que representa una factura de gimnasio.
 * Esta clase contiene la información y métodos relacionados con las facturas emitidas por el gimnasio.
 * 
 * Métodos:
 * - calcularTotal: Calcula el total de la factura.
 * - generarFactura: Genera la representación de la factura.
 * 
 * Uso:
 * Factura_Gym factura = new Factura_Gym();
 * factura.calcularTotal();
 * factura.generarFactura();
 * 
 * Dependencias:
 * - Membresia: Clase que representa una membresía.
 * 
 * @autor Oscar Gonzalez, Daniel Lopez
 * @version 1.0
 * @since 2024
 */
public class Factura_Gym {
    private String idFact;
    private Fecha fechaF;
    private Persona cliente;
    private Membresia memb;

    /**
     *
     * @param idFact
     * @param fechaF
     * @param cliente
     * @param memb
     */
    public Factura_Gym(String idFact, Fecha fechaF, Persona cliente, Membresia memb) {
        this.idFact = idFact;
        this.fechaF = fechaF;
        this.cliente = cliente;
        this.memb = memb;
    }
    
    /**
     *
     */
    public Factura_Gym() {
    this.idFact = "F-" + Math.round(100 + Math.random() * 999);
    this.fechaF = new Fecha();
    this.cliente = new Persona();
    this.memb = null; 
    }

    /**
     *
     * @param fecha
     * @return
     */
    public Fecha fechaAObjeto(String fecha)
    {
        String arrayFecha[] = fecha.split("/");
                Fecha fechaFactura = new Fecha(
                        Integer.parseInt(arrayFecha[0]),
                        Integer.parseInt(arrayFecha[1]),
                        Integer.parseInt(arrayFecha[2])
                );
         return fechaFactura;
    }
    
    /**
     *
     * @param tipoMembresia
     * @return
     */
    public Membresia membAObjeto(String tipoMembresia)
    {
        return switch (tipoMembresia.toUpperCase()) {
            case "A" -> new TipoA();
            case "B" -> new TipoB();
            case "C" -> new TipoC();
            default -> null;
        };
    }

    /**
     *
     * @return
     */
    public Persona getPropietario() {
        return cliente;
    }

    /**
     *
     * @param propietario
     */
    public void setPropietario(Persona propietario) {
        this.cliente = propietario;
    }

    /**
     *
     * @return
     */
    public String getIdFact() {
        return idFact;
    }

    /**
     *
     * @param idFact
     */
    public void setIdFact(String idFact) {
        this.idFact = idFact;
    }

    /**
     *
     * @return
     */
    public Membresia getMemb() {
        return memb;
    }

    /**
     *
     * @param memb
     */
    public void setMemb(Membresia memb) {
        this.memb = memb;
    }

    /**
     *
     * @return
     */
    public Fecha getFechaF() {
        return fechaF;
    }

    /**
     *
     * @param fechaF
     */
    public void setFechaF(Fecha fechaF) {
        this.fechaF = fechaF;
    }  
    
    /**
     *
     * @return
     */
    public Object[] Registro(){
        String tipo = "";
        if (memb instanceof TipoA)
            tipo = "A";
        else if(memb instanceof TipoB)
            tipo = "B";
        else
            tipo = "C";
        Object[] reg = {
            cliente.getID(),
            cliente.getNombre(),
            tipo,
            memb.valorPago()
        };
        return reg;
    }    

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return """
               |------------------------------------------------------|\nFactura:
               id_Factura:""" + idFact + 
                "\nFecha_Factura: " + fechaF + 
                "\nCliente: \n" + cliente.toString() +
                "\nValor Pago: " + memb.valorPago() +
                "\n|------------------------------------------------------|";
    }
}
