package modelo;

import java.util.Calendar;

/**
 * Clase utilitaria para manejar operaciones relacionadas con fechas.
 * Esta clase proporciona métodos para el manejo y formato de fechas.
 * 
 * Métodos:
 * - obtenerFechaActual: Obtiene la fecha actual.
 * - formatearFecha: Formatea una fecha en un formato específico.
 * 
 * Uso:
 * Fecha fecha = new Fecha();
 * Date fechaActual = fecha.obtenerFechaActual();
 * String fechaFormateada = fecha.formatearFecha(fechaActual, "dd/MM/yyyy");
 * 
 * Dependencias:
 * - java.util.Date: Clase para manejar fechas.
 * 
 * @autor Oscar Gonzalez, Daniel Lopez
 * @version 1.0
 * @since 2024
 */
public class Fecha {
    private int dia, mes, año;

    /**
     *
     * @param dia
     * @param mes
     * @param año
     */
    public Fecha(int dia, int mes, int año) {
        this.dia = dia;
        this.mes = mes;
        this.año = año;
    }
    
    /**
     *
     */
    public Fecha(){
        Calendar fechaSis = Calendar.getInstance();
        this.dia = fechaSis.get(Calendar.YEAR);
        this.mes = fechaSis.get(Calendar.MONTH);
        this.año = fechaSis.get(Calendar.DAY_OF_MONTH);
    }

    /**
     *
     * @return
     */
    public int getDia() {
        return dia;
    }

    /**
     *
     * @param dia
     */
    public void setDia(int dia) {
        this.dia = dia;
    }

    /**
     *
     * @return
     */
    public int getMes() {
        return mes;
    }

    /**
     *
     * @param mes
     */
    public void setMes(int mes) {
        this.mes = mes;
    }

    /**
     *
     * @return
     */
    public int getAño() {
        return año;
    }

    /**
     *
     * @param año
     */
    public void setAño(int año) {
        this.año = año;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return dia+"/"+mes+"/"+año;
    }
}
