package modelo;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.JOptionPane;
/**
 * Clase para manejar la generación de PDFs relacionados con los recaudos.
 * Esta clase proporciona métodos para crear y manipular archivos PDF de los recaudos.
 * 
 * Métodos:
 * - generarRecaudoPDF: Genera un archivo PDF con los datos del recaudo.
 * 
 * Uso:
 * RecaudoPDF recaudoPDF = new RecaudoPDF();
 * recaudoPDF.generarRecaudoPDF(recaudo);
 * 
 * Dependencias:
 * - ArchPdf: Clase base para la generación de archivos PDF.
 * 
 * @autor Oscar Gonzalez, Daniel Lopez
 * @version 1.0
 * @since 2024
 */
public class RecaudoPDF {

    private File ruta_destino;

    /**
     *
     */
    public RecaudoPDF() {
        // Define la ruta del archivo PDF en la raíz del proyecto
        this.ruta_destino = new File(System.getProperty("user.dir") + File.separator + "Recaudo_GYM.pdf");
    }

    /* Metodo que hace uso de la clase iText para manipular archivos PDF */

    /**
     *
     * @param recaudo
     */

    public void crear_PDF(Recaudo recaudo) {
        if (this.ruta_destino != null) {
            try {
                // Se crea instancia del documento
                Document mipdf = new Document();
                // Se establece una instancia a un documento PDF
                PdfWriter.getInstance(mipdf, new FileOutputStream(this.ruta_destino));
                mipdf.open(); // Se abre el documento
                mipdf.addTitle("Recaudo Gimnasio");
                mipdf.add(new Paragraph("\tFacturas de Gimnasio\n"));
                recaudo = new Recaudo();
                FacturaDAO factDAO = new FacturaDAO();
                recaudo.tablaARecaudo(factDAO.consultar());
                JOptionPane.showMessageDialog(null, recaudo.toString());
                mipdf.add(new Paragraph(recaudo.toString()));
                mipdf.add(new Paragraph("\n\n------------------------------------------------------------------------------"));
                mipdf.add(new Paragraph("Total Membresia 'A': " + factDAO.RecaudoTotal("A")));                
                mipdf.add(new Paragraph("Total Membresia 'B': " + factDAO.RecaudoTotal("B")));                
                mipdf.add(new Paragraph("Total Membresia 'C': " + factDAO.RecaudoTotal("C")));   
                mipdf.add(new Paragraph("\n\n------------------------------------------------------------------------------"));                
                mipdf.add(new Paragraph("Total Recaudo: " + factDAO.RecaudoTotal("X")));                
                mipdf.close(); // Se cierra el PDF

                JOptionPane.showMessageDialog(null, "Documento PDF creado");

                // Abre el PDF automáticamente
                abrirPDF();

            } catch (DocumentException | FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, ex.toString());
            }
        }
    }

    /* Metodo para abrir el PDF */

    /**
     *
     */

    public void abrirPDF() {
        try {
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(this.ruta_destino);
            } else {
                JOptionPane.showMessageDialog(null, "No se puede abrir el PDF automáticamente.");
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error al abrir el PDF: " + ex.getMessage());
        }
    }

    /**
     *
     * @return
     */
    public File getRuta_destino() {
        return ruta_destino;
    }

    /**
     *
     * @param ruta_destino
     */
    public void setRuta_destino(File ruta_destino) {
        this.ruta_destino = ruta_destino;
    }
}
