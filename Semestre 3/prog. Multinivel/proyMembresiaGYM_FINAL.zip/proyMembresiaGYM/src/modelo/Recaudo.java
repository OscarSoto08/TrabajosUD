/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 * Clase que representa un recaudo de pagos.
 * Esta clase contiene la información y métodos relacionados con los recaudos.
 * 
 * Métodos:
 * - calcularTotalRecaudo: Calcula el total de los recaudos.
 * - obtenerDetallesRecaudo: Obtiene los detalles de un recaudo.
 * 
 * Uso:
 * Recaudo recaudo = new Recaudo();
 * double total = recaudo.calcularTotalRecaudo();
 * String detalles = recaudo.obtenerDetallesRecaudo();
 * 
 * Dependencias:
 * - Persona: Clase que representa a la persona que realiza el pago.
 * 
 * @autor Oscar Gonzalez, Daniel Lopez
 * @version 1.0
 * @since 2024
 */
public class Recaudo {
    private ArrayList<Factura_Gym> listaF;

    /**
     *
     * @param listaF
     */
    public Recaudo(ArrayList<Factura_Gym> listaF) {
        this.listaF = listaF;
    }
    
    /**
     *
     */
    public Recaudo() {
        this.listaF = new ArrayList<>();
    }

    /**
     *
     * @return
     */
    public ArrayList<Factura_Gym> getListaF() {
        return listaF;
    }

    /**
     *
     * @param listaF
     */
    public void setListaF(ArrayList<Factura_Gym> listaF) {
        this.listaF = listaF;
    }
    
    /**
     *
     * @return
     */
    public String datos()
    {
        String datos = "";
            for (Factura_Gym factura : listaF) {
                datos += factura.toString();
        }
        return datos;
    }
    
    /**
     *
     * @return
     */
    public double valorPago()
    {
        double datos = 0;
        
            for (Factura_Gym factura : listaF) {
                datos += factura.getMemb().valorPago();
        }
        return datos;
    }

    /**
     *
     * @param tabla
     */
    public void tablaARecaudo(DefaultTableModel tabla){
        PersonaDAO objPDAO = new PersonaDAO();
        for(int i = 0; i < tabla.getRowCount(); i++)
        {
            Factura_Gym objFact = new Factura_Gym();
            String idFact = (String) tabla.getValueAt(i, 0);
            String fechaFact = (String) tabla.getValueAt(i, 1);
            int idProp = (int) tabla.getValueAt(i, 2);
            String membresia = (String) tabla.getValueAt(i, 3);
                    
            Fecha objF = objFact.fechaAObjeto(fechaFact);
            Persona cliente = objPDAO.verificarPersona(idProp);
            if(cliente == null){
                  System.out.println("Objeto persona nulo");
                  cliente = new Persona();
                  cliente.setID(""+idProp);
              }
            
            Membresia memb = objFact.membAObjeto(membresia);
                if(memb == null)
                {
                    JOptionPane.showMessageDialog(null, "Objeto membresia nulo");
                    tabla.removeRow(i);
                }
                objFact.setMemb(memb);
                
              objFact.setIdFact(idFact);
              objFact.setFechaF(objF);
              objFact.setPropietario(cliente);
              objFact.setMemb(memb);
              this.listaF.add(objFact);
        }
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return datos();
    }
    
}
