/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
/**
 * Clase para manejar la generación de PDFs relacionados con los recaudos.
 * Esta clase proporciona métodos para crear y manipular archivos PDF de los recaudos.
 * 
 * Métodos:
 * - generarRecaudoPDF: Genera un archivo PDF con los datos del recaudo.
 * 
 * Uso:
 * RecaudoPDF recaudoPDF = new RecaudoPDF();
 * recaudoPDF.generarRecaudoPDF(recaudo);
 * 
 * Dependencias:
 * - ArchPdf: Clase base para la generación de archivos PDF.
 * 
 * @autor Oscar Gonzalez, Daniel Lopez
 * @version 1.0
 * @since 2024
 */
public class TipoA extends Membresia{

    /**
     *
     */
    public TipoA() {
        super();
    }

    /**
     *
     * @param categoria
     * @param valor
     */
    public TipoA(String categoria, Double valor) {
        super("A");
        valor = valorPago();
    }
    
    /**
     *
     * @return
     */
    @Override
    public double valorPago() {
        return 65000;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return super.toString();
    }
}
