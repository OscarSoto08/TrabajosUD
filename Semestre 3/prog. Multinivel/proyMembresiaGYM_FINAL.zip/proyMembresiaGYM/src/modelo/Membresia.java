/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package modelo;

/**
 * Clase que representa una membresía de gimnasio.
 * Esta clase contiene la información y métodos relacionados con las membresías del gimnasio.
 * 
 * Métodos:
 * - calcularCosto: Calcula el costo de la membresía.
 * - obtenerDetalles: Obtiene los detalles de la membresía.
 * 
 * Uso:
 * Membresia membresia = new Membresia();
 * double costo = membresia.calcularCosto();
 * String detalles = membresia.obtenerDetalles();
 * 
 * Dependencias:
 * - TipoMembresia: Clase que representa el tipo de membresía.
 * 
 * @autor Oscar Gonzalez, Daniel Lopez
 * @version 1.0
 * @since 2024
 */

public abstract class Membresia {

    /**
     *
     */
    protected String categoria;

    /**
     * 
     * @param categoria 
     */
    public Membresia(String categoria) {
        this.categoria = categoria;
    }

    /**
     *
     */
    public Membresia() {
        this.categoria = "";
    }

    /**
     *
     * @return
     */
    public String getCategoria() {
        return categoria;
    }

    /**
     *
     * @param categoria
     */
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
    /**
     *
     * @return
     */
    public abstract double valorPago();
    
    /**
     *
     * @return
     */
    @Override
    public String toString() {
                return  "\nCategoria: " + categoria;
    }
}
