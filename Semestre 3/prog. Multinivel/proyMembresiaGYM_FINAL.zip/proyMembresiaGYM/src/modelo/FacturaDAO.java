package modelo;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 * Clase para manejar las operaciones de la base de datos relacionadas con las facturas.
 * Esta clase proporciona métodos para crear, leer, actualizar y eliminar facturas en la base de datos.
 * 
 * Métodos:
 * - crearFactura: Crea una nueva factura en la base de datos.
 * - leerFactura: Lee una factura de la base de datos por su ID.
 * - actualizarFactura: Actualiza una factura existente en la base de datos.
 * - eliminarFactura: Elimina una factura de la base de datos por su ID.
 * 
 * Uso:
 * FacturaDAO facturaDAO = new FacturaDAO();
 * facturaDAO.crearFactura(factura);
 * Factura factura = facturaDAO.leerFactura(idFactura);
 * facturaDAO.actualizarFactura(factura);
 * facturaDAO.eliminarFactura(idFactura);
 * 
 * Dependencias:
 * - ConexionBD: Clase que maneja la conexión a la base de datos.
 * 
 * @autor Oscar Gonzalez, Daniel Lopez
 * @version 1.0
 * @since 2024
 */
public class FacturaDAO {
    private Factura_Gym objF;

    /**
     *
     * @param objP
     */
    public FacturaDAO(Factura_Gym objP) {
        this.objF = objP;
    }

    /**
     *
     */
    public FacturaDAO() {
        this.objF = new Factura_Gym();
    }

    /**
     *
     * @param membresia
     * @return
     */
    public double RecaudoTotal(String membresia)
    {
        ConexionBD con = new ConexionBD();
        double valor = 0;
        try
        {
            con.conectar();
            System.out.println(con.getMensaje());
            Statement consulta = con.getConexion().createStatement();
            String sentencia = "SELECT sum(memb.Valor_Pago)"+
                    "FROM factura_gym fg "+
                    "JOIN membresia memb ON(memb.Id_Membresia = fg.Id_Membresia) ";
            switch(membresia.toUpperCase())
            {
                case "A" -> sentencia += "where memb.Id_Membresia = 'A'";
                case "B" -> sentencia += "where memb.Id_Membresia = 'B'";
                case "C" -> sentencia += "where memb.Id_Membresia = 'C'";
                default -> sentencia += "";
            }
            ResultSet datos = consulta.executeQuery(sentencia);
            ResultSetMetaData campos = datos.getMetaData();
            int cantidadColumnas = campos.getColumnCount();
            while(datos.next())
            {
                for(int i = 0; i < cantidadColumnas; i++)
                {
                    valor = (double) datos.getObject(i+1);
                }
            }
            datos.close();
            con.getConexion().close();
        }catch(SQLException  e){
            JOptionPane.showMessageDialog(null, e.toString());
        }
        catch(NullPointerException e){
            valor = 0;
        }
        return valor;
    }
    
    /**
     *
     * @return
     */
    public DefaultTableModel consultar() {
        DefaultTableModel plantilla = new DefaultTableModel();
        ConexionBD con = new ConexionBD();
        try {
            con.conectar();
            System.out.println(con.getMensaje());
            Statement consulta = con.getConexion().createStatement();
            ResultSet datos = consulta.executeQuery("SELECT * FROM factura_gym");
            ResultSetMetaData campos = datos.getMetaData();
            for (int i = 1; i <= campos.getColumnCount(); i++) {
                plantilla.addColumn(campos.getColumnName(i));
            }
            while (datos.next()) {
                Object fila[] = new Object[campos.getColumnCount()];
                for (int i = 0; i < campos.getColumnCount(); i++) {
                    fila[i] = datos.getObject(i + 1);
                }
                plantilla.addRow(fila);
            }
            datos.close();
            con.getConexion().close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString());
        }
        return plantilla;
    }

    /**
     *
     * @return
     */
    public String insertar() {
        String mensaje = "";
        try {
            ConexionBD conexion = new ConexionBD();
            Statement consulta = null;
            conexion.conectar();
            String categoria = "";
            if (objF.getMemb() instanceof TipoA) {
                categoria = "A";
            } else if (objF.getMemb() instanceof TipoB) {
                categoria = "B";
            } else {
                categoria = "C";
            }

            String comando = "INSERT INTO factura_gym (idFact, fechaF, Id_Cliente, Id_Membresia) VALUES ("
                    + "'" + objF.getIdFact() + "', "
                    + "'" + objF.getFechaF().toString() + "', "
                    + "'" + objF.getPropietario().getID() + "', "
                    + "'" + categoria + "')";
            consulta = conexion.getConexion().createStatement();
            consulta.execute(comando);
            mensaje = "Registro exitoso...";
            consulta.close();
            conexion.getConexion().close();
        } catch (SQLException ex) {
            mensaje = "Error al intentar insertar...\n" + ex;
        }
        return mensaje;
    }

    /**
     *
     * @param factura
     * @return
     */
    public String actualizarFactura(Factura_Gym factura) {
        String mensaje = "";
        try {
            ConexionBD conexion = new ConexionBD();
            conexion.conectar();
            String categoria = "";
            if (factura.getMemb() instanceof TipoA) {
                categoria = "A";
            } else if (factura.getMemb() instanceof TipoB) {
                categoria = "B";
            } else {
                categoria = "C";
            }
//UPDATE `proymembresiagym`.`factura_gym` SET `Id_Cliente` = '002' WHERE (`idFact` = '1');

            String comando = "UPDATE `proymembresiagym`.`factura_gym` SET "
                    + "`fechaF` = '" + factura.getFechaF().toString() + "', "
                    + "`Id_Cliente` = '" + factura.getPropietario().getID() + "', "
                    + "`Id_Membresia` = '" + categoria + "' "
                    + "WHERE (`idFact` = '" + factura.getIdFact() + "');";

            Statement consulta = conexion.getConexion().createStatement();
            consulta.execute(comando);
            
            int filasAfectadas = consulta.executeUpdate(comando);

                if (filasAfectadas > 0) {
                    mensaje = "Actualización exitosa.";
                } else {
                    mensaje = "Error: No se encontró el registro a actualizar.";
                }
                
            consulta.close();
            conexion.getConexion().close();
        } catch (SQLException ex) {
            mensaje = "Error al intentar actualizar...\n" + ex;
        } catch (Exception ex){
            mensaje = ex.toString();
        }
        return mensaje;
    }

    /**
     *
     * @param Fact
     * @return
     */
    public String eliminarFactura(Factura_Gym Fact) {
        String mensaje = "";
        try {
            ConexionBD conexion = new ConexionBD();
            Statement consulta = null;
            conexion.conectar();

            String comando = "DELETE FROM factura_gym WHERE idFact='" + Fact.getIdFact() + "'";
            consulta = conexion.getConexion().createStatement();
            consulta.executeUpdate(comando);
            mensaje = "Factura eliminada correctamente...";
            consulta.close();
            conexion.getConexion().close();
        } catch (SQLException ex) {
            mensaje = "Error al intentar eliminar la factura...\n" + ex;
        }
        return mensaje;
    }

    /**
     *
     * @return
     */
    public Factura_Gym getObjF() {
        return objF;
    }

    /**
     *
     * @param objF
     */
    public void setObjF(Factura_Gym objF) {
        this.objF = objF;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return objF.toString();
    }
}
