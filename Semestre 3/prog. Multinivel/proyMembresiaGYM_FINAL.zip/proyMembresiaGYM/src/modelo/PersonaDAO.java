package modelo;

import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 * Clase para manejar las operaciones de la base de datos relacionadas con las personas.
 * Esta clase proporciona métodos para crear, leer, actualizar y eliminar personas en la base de datos.
 * 
 * Métodos:
 * - crearPersona: Crea una nueva persona en la base de datos.
 * - leerPersona: Lee una persona de la base de datos por su ID.
 * - actualizarPersona: Actualiza una persona existente en la base de datos.
 * - eliminarPersona: Elimina una persona de la base de datos por su ID.
 * 
 * Uso:
 * PersonaDAO personaDAO = new PersonaDAO();
 * personaDAO.crearPersona(persona);
 * Persona persona = personaDAO.leerPersona(idPersona);
 * personaDAO.actualizarPersona(persona);
 * personaDAO.eliminarPersona(idPersona);
 * 
 * Dependencias:
 * - ConexionBD: Clase que maneja la conexión a la base de datos.
 * 
 * @autor Oscar Gonzalez, Daniel Lopez
 * @version 1.0
 * @since 2024
 */
public class PersonaDAO {
    Persona objP;

    /**
     *
     * @param objP
     */
    public PersonaDAO(Persona objP) {
        this.objP = objP;
    }
    
    /**
     *
     */
    public PersonaDAO() {
        this.objP = new Persona();
    }
    
    /**
     *
     * @return
     */
    public DefaultTableModel consultar() {
        DefaultTableModel plantilla = new DefaultTableModel();
        ConexionBD con = new ConexionBD();
        
        try {
            con.conectar();
            System.out.println(con.getMensaje());
            
            Statement consulta = con.getConexion().createStatement();
            ResultSet datos = consulta.executeQuery("select * from persona");
            ResultSetMetaData campos = datos.getMetaData();
            
            int cantidadColumnas = campos.getColumnCount();
            for (int i  = 1; i <= cantidadColumnas; i++){
                plantilla.addColumn(campos.getColumnName(i));
            }
            while (datos.next()) {
                Object[] fila = new Object[cantidadColumnas];
                for (int i = 0; i < cantidadColumnas; i++) {
                    fila[i] = datos.getObject(i+1);
                }
                plantilla.addRow(fila);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return plantilla;
    }
    
    /**
     *
     * @return
     */
    public String insertar() {
        String mensaje = "";
        
        try {
            ConexionBD conexion = new ConexionBD();
            conexion.conectar();
            
            String comando = "insert into persona(Id_Cliente, nombre, telefono, correo, ciudad, fechaNac) values (" + 
                    " '" + objP.getID() + "', " + 
                    " '" + objP.getNombre() + "', " + 
                    " '" + objP.getTelefono() + "', " + 
                    " '" + objP.getCorreo()  + "', " + 
                    " '" + objP.getCiudad() + "', " + 
                    " '" + objP.getFechaNac().toString() + "')";
            
            Statement consulta = conexion.getConexion().createStatement();
            consulta.execute(comando);
            mensaje = "Registro exitoso...";
            consulta.close();
            conexion.getConexion().close();
     
        } catch (SQLException ex) {
            mensaje = "Error al intentar insertar...\n" + ex;
        }
        return mensaje;
    }

    /**
     *
     * @param persona
     * @return
     */
    public String eliminar(Persona persona) {
        String mensaje = "";

        try {
            ConexionBD conexion = new ConexionBD();
            conexion.conectar();
            String comando = "DELETE FROM `proymembresiagym`.`persona` WHERE (`Id_Cliente` = '" + persona.getID() + "');";

            Statement consulta = conexion.getConexion().createStatement();
            int filasAfectadas = consulta.executeUpdate(comando);

            if (filasAfectadas > 0) {
                mensaje = "Eliminación exitosa.";
            } else {
                mensaje = "Error: No se encontró el registro a eliminar.";
            }

            consulta.close();
            conexion.getConexion().close();
        } catch (SQLException ex) {
            mensaje = "Error al intentar eliminar...\n" + ex;
        }

        return mensaje;
    }
    
    /**
     *
     * @param persona
     * @return
     */
    public String actualizarPersona(Persona persona) {
            String mensaje = "";
            try {
                ConexionBD conexion = new ConexionBD();
                conexion.conectar();

                //  UPDATE `proymembresiagym`.`persona` SET `nombre` = 'Mario', `ciudad` = 'Cauca', `correo` = 'mariohernandez@gmail.com', `telefono` = '3056648795', `fechaNac` = '10/06/2000' WHERE (`Id_Cliente` = '002');

                String comando = "UPDATE `proymembresiagym`.`persona` SET "
                                        + "`nombre` = '" + persona.getNombre() + "',"
                                        + "`telefono` = '" + persona.getTelefono() + "',"
                                        + "`correo` = '" + persona.getCorreo() + "',"
                                        + "`ciudad` = '" + persona.getCiudad() + "',"
                                        + "`fechaNac` = '" + persona.getFechaNac().toString() + "'"
                                        + "WHERE (`Id_Cliente` = '" + persona.getID() + "');";


                Statement consulta = conexion.getConexion().createStatement();
                consulta.execute(comando);
                int filasAfectadas = consulta.executeUpdate(comando);

                if (filasAfectadas > 0) {
                    mensaje = "Actualización exitosa.";
                } else {
                    mensaje = "Error: No se encontró el registro a actualizar.";
                }

                consulta.close();
                conexion.getConexion().close();
            } catch (SQLException ex) {
                mensaje = "Error al intentar actualizar...\n" + ex;
            }
            return mensaje;
        }
    
    /**
     *
     * @param idCliente
     * @return
     */
    public Persona verificarPersona(int idCliente)
    {
        ConexionBD con = new ConexionBD();
        try {
            con.conectar();
            System.out.println(con.getMensaje());
            String sentencia = "SELECT * FROM proymembresiagym.persona where Id_Cliente = " + idCliente + ";";
            Statement consulta = con.getConexion().createStatement();
            ResultSet datos = consulta.executeQuery(sentencia);
            ResultSetMetaData campos = datos.getMetaData();
            int cantidadColumnas = campos.getColumnCount();
            String[] registro = new String[cantidadColumnas];
            while (datos.next()) {
                for (int i = 0; i < cantidadColumnas; i++) {
                    registro[i] = (String)datos.getObject(i+1);
                }
            }
            String[] arrayFecha = registro[5].split("/");
            Fecha nacimientoPersona = new Fecha(Integer.parseInt(arrayFecha[0]), Integer.parseInt(arrayFecha[1]), Integer.parseInt(arrayFecha[2]));
            objP = new Persona(registro[0], registro[1], registro[2], registro[3], registro[4], nacimientoPersona);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        } catch (NullPointerException ex)
        {
            return null;
        }
        return objP;
    }

    /**
     *
     * @return
     */
    public Persona getObjP() {
        return objP;
    }

    /**
     *
     * @param objP
     */
    public void setObjP(Persona objP) {
        this.objP = objP;
    }
}
