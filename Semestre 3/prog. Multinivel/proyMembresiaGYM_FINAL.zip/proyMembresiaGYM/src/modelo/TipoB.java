/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;


/**
 * Clase que representa el tipo B de membresía.
 * Esta clase extiende la clase Membresia y proporciona detalles específicos para el tipo B.
 * 
 * Métodos:
 * - obtenerBeneficios: Obtiene los beneficios específicos del tipo B.
 * 
 * Uso:
 * TipoB tipoB = new TipoB();
 * String beneficios = tipoB.obtenerBeneficios();
 * 
 * Dependencias:
 * - Membresia: Clase base que representa una membresía.
 * 
 * @autor Oscar Gonzalez, Daniel Lopez
 * @version 1.0
 * @since 2024
 */
public class TipoB extends Membresia{
    
    /**
     *
     */
    public TipoB() {
        super();
    }

    /**
     *
     * @param categoria
     * @param valor
     */
    public TipoB(char categoria, Double valor) {
        super("B");
        valor = valorPago();
    }
    
    /**
     *
     * @return
     */
    @Override
    public double valorPago() {
        return 75000;
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return super.toString();
    }
}
