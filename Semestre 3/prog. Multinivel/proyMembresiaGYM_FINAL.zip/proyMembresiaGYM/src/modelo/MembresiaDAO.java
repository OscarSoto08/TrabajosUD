package modelo;

import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 * Clase para manejar las operaciones de la base de datos relacionadas con las membresías.
 * Esta clase proporciona métodos para crear, leer, actualizar y eliminar membresías en la base de datos.
 * 
 * Métodos:
 * - crearMembresia: Crea una nueva membresía en la base de datos.
 * - leerMembresia: Lee una membresía de la base de datos por su ID.
 * - actualizarMembresia: Actualiza una membresía existente en la base de datos.
 * - eliminarMembresia: Elimina una membresía de la base de datos por su ID.
 * 
 * Uso:
 * MembresiaDAO membresiaDAO = new MembresiaDAO();
 * membresiaDAO.crearMembresia(membresia);
 * Membresia membresia = membresiaDAO.leerMembresia(idMembresia);
 * membresiaDAO.actualizarMembresia(membresia);
 * membresiaDAO.eliminarMembresia(idMembresia);
 * 
 * Dependencias:
 * - ConexionBD: Clase que maneja la conexión a la base de datos.
 * 
 * @autor Oscar Gonzalez, Daniel Lopez
 * @version 1.0
 * @since 2024
 */
public class MembresiaDAO {
   Membresia objM;

    /**
     *
     * @param objM
     */
    public MembresiaDAO(Membresia objM) {
        this.objM = objM;
    }

    /**
     *
     * @return
     */
    public DefaultTableModel consultar()
    {
        DefaultTableModel plantilla = new DefaultTableModel();
        ConexionBD con = new ConexionBD();
        
        try {
            con.conectar();
            System.out.println(con.getMensaje());
            Statement consulta = con.getConexion().createStatement();
            ResultSet datos = consulta.executeQuery("select * from membresia");
            ResultSetMetaData campos = datos.getMetaData();
            
            for(int i = 1; i <= campos.getColumnCount(); i++)
                plantilla.addColumn(campos.getColumnName(i));
            
            int cantidadColumnas = campos.getColumnCount();
            while(datos.next())
            {
                Object fila[] = new Object[cantidadColumnas];
                for(int i = 0; i < cantidadColumnas; i++)
                {
                    fila[i] = datos.getObject(i+1);
                }
                plantilla.addRow(fila);
            }
            datos.close();
            con.getConexion().close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return plantilla;
    }    
    
    /**
     *
     * @return
     */
    public Membresia getObjM() {
        return objM;
    }

    /**
     *
     * @param objM
     */
    public void setObjM(Membresia objM) {
        this.objM = objM;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "MembresiaDAO{" + "objM=" + objM + '}';
    }
    
    
}

