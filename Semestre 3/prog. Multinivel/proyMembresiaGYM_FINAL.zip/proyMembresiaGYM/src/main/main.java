package main;
/**
 * Clase principal de la aplicación.
 * Esta clase contiene el método main que inicia la ejecución del programa.
 * 
 * Métodos:
 * - main: Método principal que inicia la aplicación.
 * 
 * Uso:
 * public static void main(String[] args) {
 *     // Código para iniciar la aplicación
 * }
 * 
 * Dependencias:
 * - control.Controlador_MDI: Controlador principal de la aplicación.
 * 
 * @autor Oscar Gonzalez, Daniel Lopez
 * @version 1.0
 * @since 2024
 */
import control.*;
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Controlador_MDI controlador = new Controlador_MDI();
        controlador.iniciar();
    }
}
    

