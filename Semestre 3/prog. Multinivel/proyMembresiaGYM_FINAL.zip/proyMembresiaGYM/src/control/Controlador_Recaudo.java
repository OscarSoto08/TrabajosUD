/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.FacturaDAO;
import modelo.Recaudo;
import modelo.RecaudoPDF;
import vista.vista_Recaudo;

/**
 * Controlador para manejar las operaciones de recaudo.
 * Esta clase se encarga de la lógica de negocio relacionada con el recaudo de pagos.
 * 
 * Métodos:
 * - registrarRecaudo: Registra un nuevo recaudo.
 * - actualizarRecaudo: Actualiza los datos de un recaudo existente.
 * - eliminarRecaudo: Elimina un recaudo.
 * 
 * Uso:
 * Controlador_Recaudo controlador = new Controlador_Recaudo();
 * controlador.registrarRecaudo(nuevoRecaudo);
 * controlador.actualizarRecaudo(recaudoExistente);
 * controlador.eliminarRecaudo(idRecaudo);
 * 
 * Dependencias:
 * - modelo.Recaudo: Clase que representa un recaudo.
 * - modelo.RecaudoDAO: Clase que maneja las operaciones de base de datos para los recaudos.
 * 
 * @autor Oscar Gonzalez, Daniel Lopez
 * @version 1.0
 * @since 2024
 */
public class Controlador_Recaudo implements ActionListener{
    Recaudo objR;
    vista_Recaudo vistaR;
    FacturaDAO objFDAO;
    
    public Controlador_Recaudo(Recaudo objR, vista_Recaudo vistaR) {
        this.objR = objR;
        this.vistaR = vistaR;
        this.objFDAO = new FacturaDAO();
    }
    
    public void iniciar()
    {
        this.vistaR.getBtnGuardar().addActionListener(this);
        this.vistaR.getBtnTraer().addActionListener(this);
        this.vistaR.setTitle("Recaudo de Facturas");
        this.vistaR.setLocation(50,10);
        this.vistaR.setVisible(true);
    }

    public void tablaBD()
    {
        this.vistaR.getTblDatos_Fact().setModel(objFDAO.consultar());
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource().equals(vistaR.getBtnGuardar())){
            RecaudoPDF mipdf = new RecaudoPDF();
            mipdf.crear_PDF(objR);
            mipdf.abrirPDF();
        }
        if(e.getSource().equals(vistaR.getBtnTraer())){
            tablaBD();
            
            this.vistaR.getLblValorMembA().setText(""+objFDAO.RecaudoTotal("A"));
            this.vistaR.getLblValorMembB().setText(""+objFDAO.RecaudoTotal("B"));
            this.vistaR.getLblValorMembC().setText(""+objFDAO.RecaudoTotal("C"));
            this.vistaR.getLblValorTotal().setText(""+objFDAO.RecaudoTotal("X"));
        }
    }
}
