/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.*;
import vista.*;


/**
 * Controlador para manejar las consultas de datos.
 * Esta clase se encarga de coordinar la interacción entre la vista de consulta y el modelo de datos.
 * 
 * Métodos:
 * - metodo1: Descripción del método1.
 * - metodo2: Descripción del método2.
 * 
 * Uso:
 * Controlador_Consulta controlador = new Controlador_Consulta();
 * controlador.metodo1();
 * controlador.metodo2();
 * 
 * Dependencias:
 * - modelo.ClaseModelo: Descripción de la dependencia.
 * - vista.ClaseVista: Descripción de la dependencia.
 * 
 * @autor Oscar Gonzalez
 * @version 1.0
 * @since 2024
 */

public class Controlador_Consulta implements ActionListener{
    
    vista_Consulta frmC;
    Recaudo objR;

    /**
     *
     * @param frmC
     * @param objR
     */
    public Controlador_Consulta(vista_Consulta frmC, Recaudo objR) {
        this.frmC = frmC;
        this.objR = objR;
    }
    
    /**
     *
     */
    public Controlador_Consulta() {
        this.frmC = new vista_Consulta();
    }
    
    /**
     *
     */
    public void iniciar()
    {
        this.frmC.getBtnBuscar().addActionListener(this);
        this.frmC.setTitle("Consultas Formulario");
        this.frmC.setLocation(200,200);
        this.frmC.setVisible(true);
    }

    /**
     *
     * @param tabla
     */
    public void agregarArchFactura(JTable tabla)
    {
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        Conexion con = new Conexion();
        try{    
            String []registros = con.leerDatos("DatosFactura.txt").split("\n");
            for (String registro : registros) {
                String []linea = registro.split(";");
                Object []reg = {linea[0],linea[1],linea[2],linea[3],linea[4]};
                plantilla.addRow(reg);
            }
            
        }catch(IOException error){
            JOptionPane.showMessageDialog(frmC,"Error al abrir el archivo...","Error",JOptionPane.ERROR_MESSAGE);
        }
    }   
    
    /**
     *
     * @param tabla
     */
    public void agregarArchClientes(JTable tabla)
    {
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        Conexion con = new Conexion();
        try{    
            String []registros = con.leerDatos("DatosClientes.txt").split("\n");
            for (String registro : registros) {
                String []linea = registro.split(";");
                Object []reg = {linea[0],linea[1],linea[2],linea[3],linea[4],linea[5]};
                plantilla.addRow(reg);
            }
            
        }catch(IOException error){
            JOptionPane.showMessageDialog(frmC,"Error al abrir el archivo...","Error",JOptionPane.ERROR_MESSAGE);
        }
    }   

    /**
     *
     * @param tabla
     */
    public void agregarArchMembresias(JTable tabla)
    {
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        Conexion con = new Conexion();
        try{    
            String []registros = con.leerDatos("DatosMembresia.txt").split("\n");
            for (String registro : registros) {
                String []linea = registro.split(";");
                Object []reg = {linea[0],linea[1]};
                plantilla.addRow(reg);
            }
            
        }catch(IOException error){
            JOptionPane.showMessageDialog(frmC,"Error al abrir el archivo...","Error",JOptionPane.ERROR_MESSAGE);
        }
    }   
    
    /**
     *
     * @param e
     */
    @Override
    public void actionPerformed(ActionEvent e) {
      if(e.getSource().equals(frmC.getBtnBuscar()))
      {
            agregarArchFactura(frmC.getTblDatos_Fact());
            agregarArchClientes(frmC.getTblDatos_Clientes());
            agregarArchMembresias(frmC.getTblDatos_Membresias());
      }
    }
}

