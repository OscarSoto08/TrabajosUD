package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.*;
import vista.*;
/**
 * Controlador principal para la interfaz MDI (Multiple Document Interface).
 * Esta clase coordina la interacción entre las diferentes vistas y el modelo principal de la aplicación.
 * 
 * Métodos:
 * - inicializar: Configura y muestra la interfaz MDI.
 * - mostrarVista: Muestra una vista específica en la interfaz MDI.
 * 
 * Uso:
 * Controlador_MDI controlador = new Controlador_MDI();
 * controlador.inicializar();
 * controlador.mostrarVista("vistaNombre");
 * 
 * Dependencias:
 * - vista.vista_MDI: Vista principal de la interfaz MDI.
 * 
 * @autor Oscar Gonzalez, Daniel Lopez
 * @version 1.0
 * @since 2024
 */
public class Controlador_MDI implements ActionListener{
    vista_MDI ventanaMDI;
    Recaudo recaudo;

    public Controlador_MDI(vista_MDI ventanaMDI, Recaudo recaudo) {
        this.ventanaMDI = ventanaMDI;
        this.recaudo = recaudo;
    }
    
    public Controlador_MDI() {
        this.ventanaMDI = new vista_MDI();
        this.recaudo = new Recaudo();
    }

     public void iniciar(){        

        this.ventanaMDI.getBtnConsulta().addActionListener(this);
        this.ventanaMDI.getBtnMembresia().addActionListener(this);
        this.ventanaMDI.getBtnSalir().addActionListener(this);
        this.ventanaMDI.getBtnRecaudo().addActionListener(this);
        this.ventanaMDI.getBtnConsultaBD().addActionListener(this);

        this.ventanaMDI.getMenu_Consulta().addActionListener(this);
        this.ventanaMDI.getMenu_Membresia().addActionListener(this);
        this.ventanaMDI.getMenu_Salir().addActionListener(this);
        this.ventanaMDI.getMenu_Recaudo().addActionListener(this);   
        this.ventanaMDI.getMenu_ConsultaBD().addActionListener(this);
        
        ventanaMDI.setTitle("REGISTRO CLIENTES GIMNASIO: ");
        ventanaMDI.setLocationRelativeTo(null);
        ventanaMDI.setExtendedState(JFrame.MAXIMIZED_BOTH);
        ventanaMDI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventanaMDI.setVisible(true);
    }
    
     

     
     
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==ventanaMDI.getMenu_Salir()||e.getSource()==ventanaMDI.getBtnSalir()){
            int resp = JOptionPane.showConfirmDialog(ventanaMDI, "¿Desea terminar la ejecución?", "Salida", JOptionPane.CLOSED_OPTION);
            if(resp==JOptionPane.YES_OPTION){
                ventanaMDI.dispose();
            }
        }
        
        if (e.getSource() == ventanaMDI.getMenu_Membresia() || e.getSource() == ventanaMDI.getBtnMembresia()) {
            // Comprobar si ya hay una instancia de vista_Membresia abierta
            boolean isMembresiaOpen = false;
            for (JInternalFrame frame : ventanaMDI.getEscritorio().getAllFrames()) {
                if (frame instanceof vista_Membresia) {
                    // Si ya está abierta, traerla al frente
                    frame.toFront();
                    try {
                        frame.setSelected(true); // Seleccionarla
                    } catch (java.beans.PropertyVetoException ex) {
                        ex.printStackTrace();
                    }
                    isMembresiaOpen = true;
                    break;
                }
            }

            // Si no está abierta, crear una nueva instancia
            if (!isMembresiaOpen) {
                vista_Membresia ventana_Membresia = new vista_Membresia();
                ventanaMDI.getEscritorio().add(ventana_Membresia);

                // Permitir el cierre del JInternalFrame
                ventana_Membresia.setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);

                // Agregar manejador de eventos para confirmar el cierre
                ventana_Membresia.addInternalFrameListener(new javax.swing.event.InternalFrameAdapter() {
                    @Override
                    public void internalFrameClosing(javax.swing.event.InternalFrameEvent e) {
                        int resp = JOptionPane.showConfirmDialog(ventanaMDI, "¿Desea cerrar esta ventana?", "Confirmar Cierre", JOptionPane.YES_NO_OPTION);
                        if (resp == JOptionPane.YES_OPTION) {
                            ventana_Membresia.dispose();
                        } else {
                            ventana_Membresia.setDefaultCloseOperation(JInternalFrame.DO_NOTHING_ON_CLOSE);
                        }
                    }
                });

                // Iniciar el controlador específico para la ventana
                Controlador_Membresia control_Memb = new Controlador_Membresia(ventana_Membresia);
                control_Memb.iniciar();
            }
        }

        
        if(e.getSource().equals(ventanaMDI.getBtnConsulta()) || e.getSource().equals(ventanaMDI.getMenu_Consulta()))
        {
            vista_Consulta ventana_Consulta = new vista_Consulta();
            ventanaMDI.getEscritorio().add(ventana_Consulta);   
            ventana_Consulta.setVisible(true);
            Controlador_Consulta consulta= new Controlador_Consulta(ventana_Consulta, recaudo);
            consulta.iniciar();
        }
        if(e.getSource().equals(ventanaMDI.getBtnConsultaBD()) || e.getSource().equals(ventanaMDI.getMenu_ConsultaBD()))
        {           

            vista_ConsultaBD ventana_ConsultaBD = new vista_ConsultaBD();
            ventanaMDI.getEscritorio().add(ventana_ConsultaBD);
            ventana_ConsultaBD.setVisible(true);
            Controlador_ConsultaBD consultaBD = new Controlador_ConsultaBD(ventana_ConsultaBD, recaudo);
            consultaBD.iniciar();
        }
        if(e.getSource().equals(ventanaMDI.getBtnRecaudo()) || e.getSource().equals(ventanaMDI.getMenu_Recaudo()))
        {
            vista_Recaudo ventana_recaudo = new vista_Recaudo();
            ventanaMDI.getEscritorio().add(ventana_recaudo);
            ventana_recaudo.setVisible(true);
            Controlador_Recaudo Controlrecaudo = new Controlador_Recaudo(recaudo, ventana_recaudo);
            Controlrecaudo.iniciar();
        }
        
    }
}
