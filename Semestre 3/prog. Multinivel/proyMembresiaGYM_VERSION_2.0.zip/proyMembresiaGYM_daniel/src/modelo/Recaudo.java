package modelo;

import java.util.ArrayList;

public class Recaudo {
    private ArrayList<Factura_Gym> listaF;
    private double TotalMembresiaA, TotalMembresiaB, TotalMembresiaC, TotalRecaudado;
    public Recaudo(ArrayList<Factura_Gym> listaF) {
        this.listaF = listaF;
    }

    public Recaudo() {
        this.listaF = new ArrayList<>();
    }

    public ArrayList<Factura_Gym> getListaF() {
        return listaF;
    }

    public void setListaF(ArrayList<Factura_Gym> listaF) {
        this.listaF = listaF;
    }

    public String datos() {
        StringBuilder datos = new StringBuilder();
        for (Factura_Gym factura : listaF) {
            datos.append(factura.toString()).append("\n");
        }
        return datos.toString();
    }

    public double valorPago() {
        double total = 0;
        for (Factura_Gym factura : listaF) {
            total += factura.getMemb().valorPago();
        }
        return total;
    }

    public double getTotalRecaudado() {
        double total = 0;
        for (Factura_Gym factura : listaF) {
            total += factura.getMemb().valorPago();
        }
        return total;
    }
    
    @Override
    public String toString() {
        return datos();
    }
}
