package modelo;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FacturaDAO {
    private Factura_Gym objF;

    public FacturaDAO(Factura_Gym objP) {
        this.objF = objP;
    }

    public FacturaDAO() {
        this.objF = new Factura_Gym();
    }

    public DefaultTableModel consultar() {
        DefaultTableModel plantilla = new DefaultTableModel();
        ConexionBD con = new ConexionBD();
        try {
            con.conectar();
            JOptionPane.showMessageDialog(null, con.getMensaje());
            Statement consulta = con.getConexion().createStatement();
            ResultSet datos = consulta.executeQuery("SELECT * FROM factura_gym");
            ResultSetMetaData campos = datos.getMetaData();
            for (int i = 1; i <= campos.getColumnCount(); i++) {
                plantilla.addColumn(campos.getColumnName(i));
            }
            while (datos.next()) {
                Object fila[] = new Object[campos.getColumnCount()];
                for (int i = 0; i < campos.getColumnCount(); i++) {
                    fila[i] = datos.getObject(i + 1);
                }
                plantilla.addRow(fila);
            }
            datos.close();
            con.getConexion().close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString());
        }
        return plantilla;
    }

    public String insertar() {
        String mensaje = "";
        try {
            ConexionBD conexion = new ConexionBD();
            Statement consulta = null;
            conexion.conectar();
            String categoria = "";
            if (objF.getMemb() instanceof TipoA) {
                categoria = "A";
            } else if (objF.getMemb() instanceof TipoB) {
                categoria = "B";
            } else {
                categoria = "C";
            }

            String comando = "INSERT INTO factura_gym (idFact, fechaF, Id_Cliente, Id_Membresia) VALUES ("
                    + "'" + objF.getIdFact() + "', "
                    + "'" + objF.getFechaF().toString() + "', "
                    + "'" + objF.getPropietario().getID() + "', "
                    + "'" + categoria + "')";
            consulta = conexion.getConexion().createStatement();
            consulta.execute(comando);
            mensaje = "Registro exitoso...";
            consulta.close();
            conexion.getConexion().close();
        } catch (SQLException ex) {
            mensaje = "Error al intentar insertar...\n" + ex;
        }
        return mensaje;
    }

    public String eliminarObjeto(Object objE){
        String mensaje = "";
        try{
           if(objE instanceof Membresia){
                ConexionBD conexion = new ConexionBD();
                Statement consulta = null;
                conexion.conectar();
        
               String comando = "delete from membresia "
                       + " where Id_Membresia = '" + ((Membresia) objE).getCategoria()+"'";
               consulta = conexion.getConexion().createStatement();
               consulta.executeUpdate(comando);   
               mensaje = "La membresia fue eliminada correctamente...";
               consulta.close();
               conexion.getConexion().close();
           }else if(objE instanceof Persona){
                    ConexionBD conexion = new ConexionBD();
                    Statement consulta = null;
                    conexion.conectar();
        
                String comando = "delete from persona"
                       + " where Id_Cliente = '" + ((Persona) objE).getID()+"'";
               consulta = conexion.getConexion().createStatement();
               consulta.execute(comando);      
               mensaje = "El cliente fue eliminada correctamente...";
               consulta.close();
               conexion.getConexion().close();
           }else if(objE instanceof Factura_Gym){
                ConexionBD conexion = new ConexionBD();
                Statement consulta = null;
                conexion.conectar();
        
                String comando = "delete from factura_gym "
                       + " where idFact = '" + ((Factura_Gym) objE).getIdFact()+"'";
                               System.out.println(comando);

               consulta = conexion.getConexion().createStatement();           
               consulta.executeUpdate(comando);    
               mensaje = "La factura fue eliminada correctamente...";
               consulta.close();
               conexion.getConexion().close();
           }
        }catch(SQLException ex){
            mensaje = "Error al intentar eliminar..."+ex;
        }
        return mensaje;
    }
    
    
    public String actualizarObjeto(Object objAct){
        String mensaje = "";
        try{
            ConexionBD conexion = new ConexionBD();
            Statement consulta = null;
            conexion.conectar();
            
            if(objAct instanceof Membresia){
                if(objAct instanceof TipoA){
                    TipoA tipo = (TipoA) objAct;
                }else if(objAct instanceof TipoB){
                    TipoB tipo = (TipoB) objAct;
                }else if(objAct instanceof TipoC){
                    TipoC tipo = (TipoC) objAct;
                }
                String instruccion = "update membresia " + 
                "set Valor_Pago=" + ((Membresia) objAct).valorPago() + 
                "where Id_Membresia= '" + ((Membresia) objAct).getCategoria()+"'";
                consulta = conexion.getConexion().createStatement();
                consulta.executeUpdate(instruccion);    
                mensaje = "La Membresia fue actualizada de valor correctamente...";
                consulta.close();
                conexion.getConexion().close();           
            }
            else if(objAct instanceof Persona){
                
                String instruccion = "update persona " + 
                "set nombre= '" + ((Persona) objAct).getNombre() + "'" + 
                ", ciudad= '" + ((Persona) objAct).getCiudad() + "'" + 
                ", correo= '" + ((Persona) objAct).getCorreo() + "'" + 
                ", telefono= '" + ((Persona) objAct).getTelefono() + "'" + 
                ", fechaNac= '" + ((Persona) objAct).getFechaNac() + "' " + 
                "where Id_Cliente= '" + ((Persona) objAct).getID()+"'";
                consulta = conexion.getConexion().createStatement();
                consulta.executeUpdate(instruccion);    
                mensaje = "El cliente fue actualizado correctamente...";
                consulta.close();
                conexion.getConexion().close();   
            }else if(objAct instanceof Factura_Gym){
                String categoria = null;
                if(objAct instanceof TipoA){
                    categoria = "A";
                }else if(objAct instanceof TipoB){
                    categoria = "B";
                }else if(objAct instanceof TipoC){
                    categoria = "C";
                }
                String instruccion = "update factura_gym " + 
                "set fechaF=" + ((Factura_Gym) objAct).getFechaF() + "'" + 
                ", Id_Cliente= " + ((Factura_Gym) objAct).getPropietario().getID() + "'" + 
                ", Id_Membresia= " + categoria + "'" + 
                "where idFact= '" + ((Factura_Gym) objAct).getIdFact()+"'";
                consulta = conexion.getConexion().createStatement();
                consulta.executeUpdate(instruccion);    
                mensaje = "La factura fue actualizada correctamente...";
                consulta.close();
                conexion.getConexion().close();         
            }
            
        }catch(SQLException ex){
            mensaje = "No se pudo actualizar el dato..." + ex;
        }
        return mensaje;
    }
    
    public Factura_Gym getObjF() {
        return objF;
    }

    public void setObjF(Factura_Gym objF) {
        this.objF = objF;
    }

    @Override
    public String toString() {
        return objF.toString();
    }
    
    
}
