package modelo;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import javax.swing.JOptionPane;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class RecaudoPDF {

    private File ruta_destino;

    public RecaudoPDF() {
        this.ruta_destino = new File(System.getProperty("user.dir") + File.separator + "Recaudo_GYM.pdf");
    }

    public void generarRecaudo(double totalRecaudado) {
        try {
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(ruta_destino));
            document.open();

            // Contenido del PDF
            document.add(new Paragraph("RECAUDO DE GIMNASIO"));
            document.add(new Paragraph("Total Recaudado: " + totalRecaudado));

            document.close();
            JOptionPane.showMessageDialog(null, "Documento PDF creado");

        } catch (DocumentException e) {
            JOptionPane.showMessageDialog(null, "Error al crear el PDF: " + e.getMessage());
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error al encontrar el archivo: " + e.getMessage());
        }
    }



    public void abrirPDF() {
        try {
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(this.ruta_destino);
            } else {
                JOptionPane.showMessageDialog(null, "No se puede abrir el PDF automáticamente.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error al abrir el PDF: " + ex.getMessage());
        }
    }

    public File getRuta_destino() {
        return ruta_destino;
    }

    public void setRuta_destino(File ruta_destino) {
        this.ruta_destino = ruta_destino;
    }
}
