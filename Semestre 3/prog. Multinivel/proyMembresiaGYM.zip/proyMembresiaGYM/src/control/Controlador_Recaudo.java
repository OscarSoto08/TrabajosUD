/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.FacturaDAO;
import modelo.Recaudo;
import modelo.RecaudoPDF;
import vista.vista_Recaudo;

/**
 *
 * @author FAMILIA
 */
public class Controlador_Recaudo implements ActionListener{
    Recaudo objR;
    vista_Recaudo vistaR;
    FacturaDAO objFDAO;
    
    public Controlador_Recaudo(Recaudo objR, vista_Recaudo vistaR) {
        this.objR = objR;
        this.vistaR = vistaR;
        this.objFDAO = new FacturaDAO();
    }
    
    public void iniciar()
    {
        this.vistaR.getBtnGuardar().addActionListener(this);
        this.vistaR.getBtnTraer().addActionListener(this);
        this.vistaR.setTitle("Recaudo de Facturas");
        this.vistaR.setLocation(50,10);
        this.vistaR.setVisible(true);
    }

    public void tablaBD()
    {
        this.vistaR.getTblDatos_Fact().setModel(objFDAO.consultar());
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource().equals(vistaR.getBtnGuardar())){
            RecaudoPDF mipdf = new RecaudoPDF();
            mipdf.crear_PDF(objR);
            mipdf.abrirPDF();
        }
        if(e.getSource().equals(vistaR.getBtnTraer())){
            tablaBD();
            
            this.vistaR.getLblValorMembA().setText(""+objFDAO.RecaudoTotal("A"));
            this.vistaR.getLblValorMembB().setText(""+objFDAO.RecaudoTotal("B"));
            this.vistaR.getLblValorMembC().setText(""+objFDAO.RecaudoTotal("C"));
            this.vistaR.getLblValorTotal().setText(""+objFDAO.RecaudoTotal("X"));
        }
    }
}
