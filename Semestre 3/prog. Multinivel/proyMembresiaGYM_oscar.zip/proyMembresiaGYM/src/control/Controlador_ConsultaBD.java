package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.*;
import vista.*;

public class Controlador_ConsultaBD implements ActionListener, MouseListener {
    private vista_ConsultaBD frmC;
    private Recaudo objR;
    private Factura_Gym objF;
    private Membresia objM;
    Object objRegistro;
    JTable tablaDatos;

    public Controlador_ConsultaBD() {
        this.objR = new Recaudo();
        this.frmC = new vista_ConsultaBD();
        this.objF = new Factura_Gym();
        this.tablaDatos = new JTable();
    }

    public Controlador_ConsultaBD(JInternalFrame form, Recaudo objR) {
        this.objR = objR;
        this.frmC = (vista_ConsultaBD) form;
        this.objF = new Factura_Gym();
    }

    public void iniciar() {
        this.frmC.getBtnBuscar().addActionListener(this);
        this.frmC.getBtnActualizar().addActionListener(this);
        this.frmC.getBtnEliminar().addActionListener(this);

        this.frmC.getTblDatos_Clientes().addMouseListener(this);
        this.frmC.getTblDatos_Fact().addMouseListener(this);
        this.frmC.getTblDatos_Membresias().addMouseListener(this);

        frmC.setTitle("Consulta BD");
        frmC.setLocation(50, 10);
        frmC.setVisible(true);
        BDTabla();
    }

    public void BDTabla() {
        PersonaDAO objPDAO = new PersonaDAO();
        MembresiaDAO objMDAO = new MembresiaDAO(objM);
        FacturaDAO objFDAO = new FacturaDAO();

        frmC.getTblDatos_Clientes().setModel(objPDAO.consultar());
        frmC.getTblDatos_Fact().setModel(objFDAO.consultar());
        frmC.getTblDatos_Membresias().setModel(objMDAO.consultar());
    }

    public String enviarDatosDAO(JTable tabla) {
        String mensaje = "";

        tablaDatos = tabla;
        int fila = tabla.getSelectedRow();

//        if (fila < 0) {
//            mensaje = "No hay una fila seleccionada.";
//            return mensaje;
//        }

        String columna0 = tabla.getColumnName(0);
        String valor0 = tabla.getValueAt(fila, 0).toString();
        
        try {
            if (columna0.equals("Id_Membresia")) {
                switch (valor0.toUpperCase()) {
                    case "A":
                        TipoA A = new TipoA();
                        objRegistro = A;
                        break;
                    case "B":
                        TipoB B = new TipoB();
                        objRegistro = B;
                        break;
                    case "C":
                        TipoC C = new TipoC();
                        objRegistro = C;
                        break;
                    default:
                        mensaje = "Tipo de membresía no reconocido: " + valor0;
                        return mensaje;
                }
            } 
            else if (columna0.equals("Id_Cliente")) {
                //objeto fecha de nacimiento para persona: 
                
                String arrayFecha[] = tabla.getValueAt(fila, 5).toString().split("/");
                Fecha nacimientoCliente = new Fecha(
                        Integer.parseInt(arrayFecha[0]),
                        Integer.parseInt(arrayFecha[1]),
                        Integer.parseInt(arrayFecha[2])
                );
                
                String nombre = tabla.getValueAt(fila, 1).toString();
                String telefono = tabla.getValueAt(fila, 2).toString();
                String correo = tabla.getValueAt(fila, 3).toString();
                String ciudad = tabla.getValueAt(fila, 4).toString();
                
                
                Persona objPersona = new Persona(
                        valor0,
                        nombre,
                        telefono,
                        correo,
                        ciudad,
                        nacimientoCliente
                );
                objRegistro = objPersona;
            } else if (columna0.equals("idFact")) {
                String idFact = tabla.getValueAt(fila, 0).toString();
                String fechaStr  = tabla.getValueAt(fila, 1).toString();
                String idCliente = tabla.getValueAt(fila, 2).toString();
                String tipoMembresia = tabla.getValueAt(fila, 3).toString();
                
                Factura_Gym objFactura = new Factura_Gym();
                
                objFactura.setIdFact(idFact);
                //Pasar de string a objeto fecha de factura y colocarlo
                objFactura.setFechaF(objFactura.fechaAObjeto(fechaStr));
                //el id del propietario existe?
                PersonaDAO objPDAO = new PersonaDAO();
                Persona cliente = objPDAO.verificarPersona(Integer.parseInt(idCliente));
                
              if(cliente == null){
                  System.out.println("Objeto persona nulo");
                  cliente = new Persona();
                  cliente.setID(idCliente);
              }
                objFactura.setPropietario(cliente);
              
                
                //Pasar de string a objeto membresia y setearlo a factura
                Membresia memb = objFactura.membAObjeto(tipoMembresia);
                
                if(memb == null)
                    System.out.println("Objeto membresia nulo");
                
                objFactura.setMemb(memb);
                objRegistro = objFactura;
            } else {
                mensaje = "Columna desconocida: " + columna0;
                return mensaje;
            }
        } catch (NumberFormatException ex) {
            mensaje = "Error al convertir un valor a número: " + ex;
            return mensaje;
        } catch (ArrayIndexOutOfBoundsException ex) {
            mensaje = "Error: Acceso a columna fuera de límites: " + ex;
            return mensaje;
        } catch (ClassCastException ex) {
            mensaje = "Error de tipo de datos: " + ex;
            return mensaje;
        }catch(NullPointerException ex){
            mensaje = "Error en puntero nulo" + ex;
            return mensaje;
        }
        mensaje = "Datos procesados correctamente.";
        return mensaje;
    }

    public boolean verificar(String oper) {
        try {
            if(objRegistro != (null))
            {
                int resp = JOptionPane.showConfirmDialog(frmC, objRegistro.toString() +
                "\n¿Está seguro de " + oper + " estos datos?", oper, JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

                return resp == JOptionPane.YES_OPTION;
            }
             
        }catch(java.lang.NullPointerException ex)
        {
            JOptionPane.showMessageDialog(frmC, "Error con factura: Está intentando modificar la factura de un cliente que no existe...\n" + ex.getMessage());
        }
        return true;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource().equals(frmC.getBtnActualizar())) {
            if (verificar("Actualizar")) {
                String mensaje = "";
                if (tablaDatos.equals(frmC.getTblDatos_Clientes())) {
                    mensaje = actualizarCliente(objRegistro);
                } else if (tablaDatos.equals(frmC.getTblDatos_Fact())) {
                    mensaje = actualizarFactura(objRegistro);
                }
                JOptionPane.showMessageDialog(frmC, mensaje);
                BDTabla();
            }
        }

        if (e.getSource().equals(frmC.getBtnBuscar())) {
            BDTabla();
        }

        if (e.getSource().equals(frmC.getBtnEliminar())) {
            if (tablaDatos == null) {
                JOptionPane.showMessageDialog(frmC, "No se ha seleccionado ninguna tabla.");
                return;
            }

            if (verificar("Eliminar")) {
                DefaultTableModel plantilla = (DefaultTableModel) tablaDatos.getModel();
                int filaSeleccionada = tablaDatos.getSelectedRow();

                if (filaSeleccionada < 0) {
                    JOptionPane.showMessageDialog(frmC, "No se ha seleccionado ninguna fila.");
                    return;
                }

                if (tablaDatos.equals(frmC.getTblDatos_Clientes())) {
                    JOptionPane.showMessageDialog(frmC,eliminarCliente(objRegistro));
                } else if (tablaDatos.equals(frmC.getTblDatos_Fact())) {
                    JOptionPane.showMessageDialog(frmC, eliminarFactura(objRegistro));
                }

                plantilla.removeRow(filaSeleccionada);
            } else {
                BDTabla();
            }
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getSource().equals(frmC.getTblDatos_Fact())) {
            enviarDatosDAO(frmC.getTblDatos_Fact());
            
        } else if (e.getSource().equals(frmC.getTblDatos_Clientes())) {
            enviarDatosDAO(frmC.getTblDatos_Clientes());
        } else if (e.getSource().equals(frmC.getTblDatos_Membresias())) {
            enviarDatosDAO(frmC.getTblDatos_Membresias());
        }
    }
 
    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // Implementación si es necesario
    }

    @Override
    public void mouseExited(MouseEvent e) {
        // Implementación si es necesario
        
    }

    private String eliminarCliente(Object objRegistro) {
        PersonaDAO personaDAO = new PersonaDAO();
        if (objRegistro instanceof Persona) {
            return personaDAO.eliminar((Persona) objRegistro);
        }
        return "Error: El objeto no es una instancia de Persona.";
    }

    private String eliminarFactura(Object objRegistro) {
        FacturaDAO facturaDAO = new FacturaDAO();
        if (objRegistro instanceof Factura_Gym) {
            return facturaDAO.eliminarFactura((Factura_Gym) objRegistro);
        }
        return "Error: El objeto no es una instancia de Factura_Gym.";
    }

    private String actualizarCliente(Object objRegistro) {
        if (!(objRegistro instanceof Persona)) {
            return "Error: El objeto no es una instancia de Persona.";
        }
        PersonaDAO personaDAO = new PersonaDAO();
        JOptionPane.showMessageDialog(frmC, objRegistro.toString());
        return personaDAO.actualizarPersona((Persona) objRegistro);
    }

    private String actualizarFactura(Object objRegistro) {
        if (!(objRegistro instanceof Factura_Gym)) {
            return "Error: El objeto no es una instancia de Factura_Gym.";
        }
        FacturaDAO facturaDAO = new FacturaDAO();
        return facturaDAO.actualizarFactura((Factura_Gym) objRegistro);
    }
}
