package modelo;

import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author FAMILIA
 */
public class MembresiaDAO {
   Membresia objM;

    /**
     *
     * @param objM
     */
    public MembresiaDAO(Membresia objM) {
        this.objM = objM;
    }

    /**
     *
     * @return
     */
    public DefaultTableModel consultar()
    {
        DefaultTableModel plantilla = new DefaultTableModel();
        ConexionBD con = new ConexionBD();
        
        try {
            con.conectar();
            System.out.println(con.getMensaje());
            Statement consulta = con.getConexion().createStatement();
            ResultSet datos = consulta.executeQuery("select * from membresia");
            ResultSetMetaData campos = datos.getMetaData();
            
            for(int i = 1; i <= campos.getColumnCount(); i++)
                plantilla.addColumn(campos.getColumnName(i));
            
            int cantidadColumnas = campos.getColumnCount();
            while(datos.next())
            {
                Object fila[] = new Object[cantidadColumnas];
                for(int i = 0; i < cantidadColumnas; i++)
                {
                    fila[i] = datos.getObject(i+1);
                }
                plantilla.addRow(fila);
            }
            datos.close();
            con.getConexion().close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return plantilla;
    }    
    
    /**
     *
     * @return
     */
    public Membresia getObjM() {
        return objM;
    }

    /**
     *
     * @param objM
     */
    public void setObjM(Membresia objM) {
        this.objM = objM;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "MembresiaDAO{" + "objM=" + objM + '}';
    }
    
    
}

