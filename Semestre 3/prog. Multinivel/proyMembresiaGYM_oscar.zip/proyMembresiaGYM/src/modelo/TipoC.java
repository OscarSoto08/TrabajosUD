/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author FAMILIA
 */
public class TipoC extends Membresia{
    
    /**
     *
     */
    public TipoC() {
        super();
    }

    /**
     *
     * @param categoria
     * @param valor
     */
    public TipoC(char categoria, Double valor) {
        super("C");
        valor = valorPago();
    }
    
    /**
     *
     * @return
     */
    @Override
    public double valorPago() {
        return 650000;
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return super.toString();
    }
}
