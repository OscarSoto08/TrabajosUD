/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package modelo;

/**
 *
 * @author FAMILIA
 */

public abstract class Membresia {

    /**
     *
     */
    protected String categoria;

    /**
     * 
     * @param categoria 
     */
    public Membresia(String categoria) {
        this.categoria = categoria;
    }

    /**
     *
     */
    public Membresia() {
        this.categoria = "";
    }

    /**
     *
     * @return
     */
    public String getCategoria() {
        return categoria;
    }

    /**
     *
     * @param categoria
     */
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
    /**
     *
     * @return
     */
    public abstract double valorPago();
    
    /**
     *
     * @return
     */
    @Override
    public String toString() {
                return  "\nCategoria: " + categoria;
    }
}
