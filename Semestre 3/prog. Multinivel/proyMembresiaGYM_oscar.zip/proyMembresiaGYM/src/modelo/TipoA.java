/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author FAMILIA
 */
public class TipoA extends Membresia{

    /**
     *
     */
    public TipoA() {
        super();
    }

    /**
     *
     * @param categoria
     * @param valor
     */
    public TipoA(String categoria, Double valor) {
        super("A");
        valor = valorPago();
    }
    
    /**
     *
     * @return
     */
    @Override
    public double valorPago() {
        return 65000;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return super.toString();
    }
}
