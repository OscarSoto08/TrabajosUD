/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author FAMILIA
 */
public class TipoB extends Membresia{
    
    /**
     *
     */
    public TipoB() {
        super();
    }

    /**
     *
     * @param categoria
     * @param valor
     */
    public TipoB(char categoria, Double valor) {
        super("B");
        valor = valorPago();
    }
    
    /**
     *
     * @return
     */
    @Override
    public double valorPago() {
        return 75000;
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return super.toString();
    }
}
