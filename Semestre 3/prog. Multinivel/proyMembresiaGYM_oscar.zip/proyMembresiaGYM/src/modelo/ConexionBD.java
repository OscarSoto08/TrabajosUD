/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Sonia Pinzón
 */
public class ConexionBD {
  private Connection conexion;
  private String bd,usuario, clave,mensaje;

    /**
     *
     * @param conexion
     * @param bd
     * @param usuario
     * @param clave
     * @param mensaje
     */
    public ConexionBD(Connection conexion, String bd, String usuario, String clave, String mensaje) {
        this.conexion = conexion;
        this.bd = bd;
        this.usuario = usuario;
        this.clave = clave;
        this.mensaje = mensaje;
    }

    /**
     *
     */
    public ConexionBD() {
        this.conexion = null;
        this.bd = "proymembresiagym";
        this.usuario = "root";
        this.clave = "123456";
        this.mensaje = "";
    }

    /**
     *
     */
    public void conectar(){
    boolean resp=true;
      try {
          Class.forName("com.mysql.jdbc.Driver");
          String ruta="jdbc:mysql://127.0.0.1:3306/"+bd;
          System.out.println(ruta);
          conexion= DriverManager.getConnection(ruta,usuario,clave);
          if (conexion!=null){
          mensaje="Conexion establecida con éxito...";}
          else
          mensaje="No se pudo establecer conexion...";;
      } catch (ClassNotFoundException ex) {
          mensaje="No se pudo establecer conexion...";
      } catch (SQLException ex) {
           mensaje=" No se puede conectar con MySQL...";
      }
     
}  

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "Conexion{" + "conexion=" + conexion + ", bd=" + bd + ", usuario=" + usuario + ", clave=" + clave + ", mensaje=" + mensaje + '}';
    }

    /**
     *
     * @return
     */
    public Connection getConexion() {
        return conexion;
    }

    /**
     *
     * @param conexion
     */
    public void setConexion(Connection conexion) {
        this.conexion = conexion;
    }

    /**
     *
     * @return
     */
    public String getBd() {
        return bd;
    }

    /**
     *
     * @param bd
     */
    public void setBd(String bd) {
        this.bd = bd;
    }

    /**
     *
     * @return
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     *
     * @param usuario
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    /**
     *
     * @return
     */
    public String getClave() {
        return clave;
    }

    /**
     *
     * @param clave
     */
    public void setClave(String clave) {
        this.clave = clave;
    }

    /**
     *
     * @return
     */
    public String getMensaje() {
        return mensaje;
    }

    /**
     *
     * @param mensaje
     */
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }  
}
