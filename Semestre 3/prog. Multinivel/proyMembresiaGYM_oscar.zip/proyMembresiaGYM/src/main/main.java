package main;
/**
 * La clase Main se encarga de iniciar el programa a partir de una instancia del controlador principal que gestiona las acciones del usuario en la ventana MDI
 * @author Daniel Lopez
 * @author Oscar Gonzalez 
 * @version 6.0
 */

import control.*;
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Controlador_MDI controlador = new Controlador_MDI();
        controlador.iniciar();
    }
}
    

