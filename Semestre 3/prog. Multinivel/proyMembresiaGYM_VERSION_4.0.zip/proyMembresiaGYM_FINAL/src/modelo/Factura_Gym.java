package modelo;
/**
 * @author Daniel López Valderrama
 * @author Oscar Gonzalez Soto
 */

/**
 * La clase Factura_Gym representa una factura de gimnasio e incluye información sobre la membresía adquirida, la fecha de emisión y los datos del cliente.
 */
public class Factura_Gym {
    /** Identificador único de la factura. */
    private String idFact;
    /** Objeto que representa la membresía adquirida. */
    private Membresia memb;
    /** Fecha de emisión de la factura. */
    private Fecha fechaF;
    /** Cliente al que se emite la factura. */
    private Persona cliente;

    /**
     *
     * @param idFact
     * @param memb
     * @param fechaF
     * @param cliente
     */
    public Factura_Gym(String idFact, Membresia memb, Fecha fechaF, Persona cliente) {
        this.idFact = idFact;
        this.memb = memb;
        this.fechaF = fechaF;
        this.cliente = cliente;
    }
    
    /**
     * Constructor de la clase Factura_Gym que inicializa todos los atributos de la factura.
     * Genera un identificador único para la factura, inicializa la fecha de emisión y crea un cliente y una membresía vacíos.
     */
    public Factura_Gym() {
    this.idFact = "F-" + Math.round(100 + Math.random() * 999);
    this.fechaF = new Fecha();
    this.cliente = new Persona();
    this.memb = null; 
    }

    /**
     * Método que devuelve el cliente al que se emite la factura.
     * @return El cliente al que se emite la factura.
     */
    public Persona getPropietario() {
        return cliente;
    }
    /**
     * Método que establece el cliente al que se emite la factura.
     * @param propietario El nuevo cliente al que se emite la factura.
     */
    public void setPropietario(Persona propietario) {
        this.cliente = propietario;
    }
    /**
     * Método que devuelve el identificador único de la factura.
     * @return El identificador único de la factura.
     */
    public String getIdFact() {
        return idFact;
    }
    /**
     * Método que establece el identificador único de la factura.
     * @param idFact El nuevo identificador único de la factura.
     */
    public void setIdFact(String idFact) {
        this.idFact = idFact;
    }
    /**
     * Método que devuelve la membresía adquirida.
     * @return La membresía adquirida.
     */
    public Membresia getMemb() {
        return memb;
    }
    /**
     * Método que establece la membresía adquirida.
     * @param memb La nueva membresía adquirida.
     */
    public void setMemb(Membresia memb) {
        this.memb = memb;
    }
    /**
     * Método que devuelve la fecha de emisión de la factura.
     * @return La fecha de emisión de la factura.
     */
    public Fecha getFechaF() {
        return fechaF;
    }
    /**
     * Método que establece la fecha de emisión de la factura.
     * @param fechaF La nueva fecha de emisión de la factura.
     */
    public void setFechaF(Fecha fechaF) {
        this.fechaF = fechaF;
    }  
    /**
     * Método que genera un registro de la factura para ser utilizado en una tabla u otra presentación similar.
     * @return Un arreglo de objetos que representa un registro de la factura.
     */
    public Object[] Registro(){
        String tipo = "";
        if (memb instanceof TipoA)
            tipo = "A";
        else if(memb instanceof TipoB)
            tipo = "B";
        else
            tipo = "C";
        Object[] reg = {
            cliente.getID(),
            cliente.getNombre(),
            tipo,
            memb.valorPago()
        };
        return reg;
    }
    
    /**
     * Método estático que convierte una cadena de texto en una instancia de la clase Membresia.
     * @param tipo Cadena que representa el tipo de membresía.
     * @return Una instancia de la clase Membresia correspondiente al tipo especificado.
     */
    public static Membresia convertirStringAMembresia(String tipo) {
        switch(tipo) {
            case "A":
                return new TipoA();
            case "B":
                return new TipoB();
            case "C":
                return new TipoC();
            default:
            // Lanza una excepción o retorna un valor por defecto
            throw new IllegalArgumentException("Tipo de membresía no válido: " + tipo);
        }
    }

    /**
     * Método estático que convierte una cadena de texto en una instancia de la clase Fecha.
     * @param fechaStr Cadena que representa la fecha en formato "dd/MM/yyyy".
     * @return Una instancia de la clase Fecha correspondiente a la cadena especificada.
     * @throws IllegalArgumentException Si la cadena no está en el formato esperado.
     */
    public static Fecha convertirStringAFecha(String fechaStr) {
        // Suponiendo el formato de fecha "dd/MM/yyyy"
        String[] partes = fechaStr.split("/");

        if (partes.length != 3) {
            // Manejo de error si la fecha no está en el formato esperado
            throw new IllegalArgumentException("Formato de fecha no válido. Debe ser dd/MM/yyyy.");
        }

        try {
            int dia = Integer.parseInt(partes[0]);
            int mes = Integer.parseInt(partes[1]);
            int año = Integer.parseInt(partes[2]);

            return new Fecha(dia, mes, año);
        } catch (NumberFormatException e) {
            // Manejo de error si las partes no son enteros válidos
            throw new IllegalArgumentException("Fecha contiene valores no numéricos.");
        }
    }

    /**
     * Método estático que convierte una cadena de texto en una instancia de la clase Persona.
     * @param personaStr Cadena que contiene los datos de la persona separados por comas en el formato "nombre,telefono,correo,ciudad,ID".
     * @return Una instancia de la clase Persona con los datos especificados en la cadena.
     * @throws IllegalArgumentException Si la cadena no está en el formato esperado.
     */
    public static Persona convertirStringAPersona(String personaStr) {
        // Suponiendo que los datos de la persona están separados por comas en la cadena
        // Formato esperado: "nombre,telefono,correo,ciudad,ID"
        String[] partes = personaStr.split(",");

        if (partes.length != 6) {
            // Manejo de error si la cadena no contiene los 5 campos esperados
            throw new IllegalArgumentException("Formato de datos de persona no válido. Debe ser nombre,telefono,correo,ciudad,ID.");
        }

        // Asignar cada parte a la variable correspondiente
        String ID = partes[0].trim();
        String nombre = partes[1].trim();
        String telefono = partes[2].trim();
        String correo = partes[3].trim();
        String ciudad = partes[4].trim();
        String fecha = partes[5].trim();
        

        // Crear y retornar un objeto Persona
        return new Persona(nombre, telefono, correo, ciudad, ID, fecha);
    }

    /**
     * Método que devuelve una representación en forma de String de la factura.
     * @return Una representación en forma de String de la factura.
     */
    @Override
    public String toString() {
        return """
               |------------------------------------------------------|\nFactura:
               id_Factura:""" + idFact + 
                "\nFecha_Factura: " + fechaF + 
                "\nCliente: \n" + cliente.toString() +
                "\nValor Pago: " + memb.valorPago() +
                "\n|------------------------------------------------------|";
    }
    
    
}
