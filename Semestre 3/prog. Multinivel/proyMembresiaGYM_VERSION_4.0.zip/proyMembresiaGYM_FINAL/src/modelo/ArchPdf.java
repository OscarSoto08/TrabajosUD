package modelo;
/**
 * @author Daniel López Valderrama
 * @author Oscar Gonzalez Soto
 * @author Sonia Pinzon
 */
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.JOptionPane;
/**
 * La clase ArchPdf permite crear y manipular archivos PDF que contienen información sobre las facturas de un gimnasio.
 */
public class ArchPdf {
    /** Ruta de destino para guardar el archivo PDF. */
    private File ruta_destino;

    /**
     * Constructor de la clase ArchPdf.
     * Establece la ruta de destino para guardar el archivo PDF en la raíz del proyecto.
     */
    public ArchPdf() {
        // Define la ruta del archivo PDF en la raíz del proyecto
        this.ruta_destino = new File(System.getProperty("user.dir") + File.separator + "Persistencia_GYM.pdf");
    }

     /**
     * Método que crea un archivo PDF con los datos proporcionados y lo guarda en la ruta de destino especificada.
     * @param objF Objeto Factura_Gym que contiene los datos a incluir en el PDF.
     */
     public void crear_PDF(Factura_Gym objF) {
        if (this.ruta_destino != null) {
            try {
                // Se crea instancia del documento
                Document mipdf = new Document();
                // Se establece una instancia a un documento PDF
                PdfWriter.getInstance(mipdf, new FileOutputStream(this.ruta_destino));
                mipdf.open(); // Se abre el documento
                mipdf.addTitle("Datos Gimnasio");

                mipdf.add(new Paragraph("\tFacturas de Gimnasio\n"));

                mipdf.add(new Paragraph(objF.toString())); // Añade el contenido del PDF
                mipdf.close(); // Se cierra el PDF

                JOptionPane.showMessageDialog(null, "Documento PDF creado");

                // Abre el PDF automáticamente
                abrirPDF();

            } catch (DocumentException | FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, ex.toString());
            }
        }
    }

    /**
     * Método que abre el archivo PDF utilizando el programa predeterminado del sistema.
     */
    public void abrirPDF() {
        try {
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(this.ruta_destino);
            } else {
                JOptionPane.showMessageDialog(null, "No se puede abrir el PDF automáticamente.");
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error al abrir el PDF: " + ex.getMessage());
        }
    }
    
    /**
     * Método que devuelve la ruta de destino del archivo PDF.
     * @return La ruta de destino del archivo PDF.
     */
    public File getRuta_destino() {
        return ruta_destino;
    }
    
     /**
     * Método que establece la ruta de destino del archivo PDF.
     * @param ruta_destino La nueva ruta de destino del archivo PDF.
     */
    public void setRuta_destino(File ruta_destino) {
        this.ruta_destino = ruta_destino;
    }
}
