package main;

import control.*;
//import java.text.DecimalFormat;

public class HerenciaVehiculos {
    public static void main(String[] args) {
        ControladorFRM control =  new ControladorFRM();
        control.iniciar();
//        double c = 123456789.123456789;
//        DecimalFormat df = new DecimalFormat("#.00");
//        System.out.println(df.format(c));
    }
}
