/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejspinneroscargonzalez;

import controlador.Control;

/**
 *
 * @author FAMILIA
 */
public class proyIMC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Control objC = new Control();
        objC.iniciar();
    }
    
}
